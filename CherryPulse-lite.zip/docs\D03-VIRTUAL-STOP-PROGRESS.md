# D03 가상 손절 보호 진행 기록

## 관찰 도구 테스트 Ruff 정리 — 2026-10-13

`tests/test_realtime_probe.py`의 기존 Ruff 19건을 해소했다. 동작 변경은
없다: import 정리·unittest 단언→일반 단언·단일 `with`·`pytest.raises`에
공통 prefix match를 붙였다. Qt API를 흉내 내는 `isNull`·`dynamicCall`·
`singleShot` 이름은 도구가 호출하는 실명이므로 개명하지 않고 `noqa` 근거를
달았다. 길었던 콜백 테스트는 실행 헬퍼 분리로 둘로 나눴다(필터·주문 API
미호출). 과정에서 들여쓰기 파손 1건을 테스트 실패로 확인하고 복구했다.
검증: 해당 파일 Ruff check·format 통과, 관련 테스트 포함 전체 pytest
**182 passed**. 키움 로그인·주문/조회·운영 DB·배포는 실행하지 않았다.

## 출근 전 로그인 후 장중 무인 시세 관찰 — 2026-09-26

직장 근무로 장중 직접 조작할 수 없는 운영 조건에 맞춰 독립 관찰 도구에 `--start-at HH:MM`을 추가했다. 지정 PC에서 **거래일 아침**, Windows에 로그인한 사용자 세션에서 도구를 실행하고 키움 로그인 창이 나오면 출근 전에 완료한다. 도구는 같은 날 PC 로컬 시각이 지정 시간에 도달할 때까지 대기한 뒤 한 종목의 실시간 등록을 시작한다. 시작 시간이 이미 지났거나 8시간 넘게 남았으면 거절하며, PC 절전 등으로 지정 시간을 30초 넘게 놓치면 등록하지 않는다. 이후 기존 `--seconds`(최대 120초)가 지나면 해제를 요청하고 종료한다. 이 기능은 실제 시장 개장 여부를 판정하지 않는다.

PowerShell에서 `git pull origin main` 후 다음을 **출근 전 한 번만** 실행하는 예시다. 아래 경로는 사용자 프로필의 바탕화면 파일이며 운영 DB가 아니다. 저장된 출력에는 `fid10`·`fid20` 원문이 포함될 수 있으므로 공유 전 계좌·개인 정보가 없는지 확인한다.

```powershell
py -3.10-32 tools\inspect_kiwoom_realtime.py 005930 --start-at 09:05 --seconds 120 2>&1 | Tee-Object -FilePath "$env:USERPROFILE\Desktop\CherryPulse-quote-$(Get-Date -Format yyyyMMdd).txt"
```

PC 전원과 사용자 세션을 유지하고 절전은 해제해야 한다. 보안 프로그램·키움 로그인이 다시 필요해지면 이 방식은 무인 실행을 보장하지 않으므로 해당 오류만 기록하고 종료한다. 계정 비밀번호 저장이나 Windows 작업 스케줄러의 비대화형 계정 실행을 전제로 하지 않는다. 설치 PC에서 이 새 대기 경로의 실제 실행은 아직 미검증이다. `python -m unittest tests.test_realtime_probe -v`의 예약시각 검증과 기존 모의 콜백 검사 **2 tests OK**(Linux Python 3.12), `git diff --check` 통과. 키움 원문, 정규장, 실제 주문, 운영 DB는 확인·변경하지 않았다.

## 실시간 관찰 도구의 반복 가능한 경계 검사 — 2026-09-26

`tests/test_realtime_probe.py`에 Windows OCX 없이 실행하는 모의 이벤트 검사를 추가했다. 다른 종목·다른 실시간 타입을 무시하고 지정 종목 `주식체결` 두 콜백에서 FID 원문을 `repr`로 출력하는지, 등록 성공 뒤 30초 타이머가 설정되는지, 종료 때 실시간 등록을 한 번 해제하는지 검사한다. 주문·TR·계좌조회 메서드 호출이 없다는 조건도 검사한다. Linux Python 3.12에서 `python -m unittest tests.test_realtime_probe -v` **1 test OK**, `git diff --check` 통과. Windows Python 3.10 32비트 및 실제 키움 OCX 실행은 아직 미검증이며, 모의 검사를 시세 원문 규격이나 거래소 세션의 근거로 승격하지 않는다.

## D03 관찰 도구 오프라인 호출 검증 — 2026-09-26

Linux Python 3.12에서 ActiveX/Qt 경계를 메모리 모의 객체로 대체해 관찰 도구를 실행했다. 다른 종목 콜백 1건은 무시하고 지정 종목 `주식체결` 콜백 2건에서 각 FID 10·20·290·9081을 읽었다. 로그인 대기용 60초 타이머와 등록 성공 뒤 30초 관찰 타이머를 확인했고, 종료 시 `SetRealRemove` 1회, `SendOrder`/TR/계좌 조회 호출 0회를 확인했다. **모의 객체 검사 통과**. 이 검사는 Kiwoom OCX의 실제 시그니처·서버 응답, 원문 값, Windows 이벤트 루프의 정상 해제 동작을 증명하지 않는다.

가상 원장의 기존 부분 매도·추가 매수 체결·취소/거절 `UNKNOWN`·재시작 테스트 범위를 재검토했다. 이미 있는 테스트만으로 실제 증권사 응답 대조나 세션 판정이 해결되었다고 승격하지 않는다. 이 환경은 Windows OCX 및 32비트 Python에 접근하지 못하며, 주문 기능 연결 없이 진행할 다음 입력은 지정 PC의 장중 `fid10`·`fid20` 원문과 수신 순번이다. 따라서 실시간 어댑터 구현과 D03 완료 판정은 보류한다.

## 동일 체결시각의 서로 다른 이벤트 구분 근거 — 2026-09-26

가상 원장의 `_quote_rejection_reason`은 같은 `Quote.received_at`을 `QUOTE_DUPLICATE`로 거절한다. 이 값은 현행 가상 계약의 **로컬 수신시각**이며, FID 20의 체결시간을 그 자리에 대입하면 같은 초의 별개 콜백을 중복으로 버릴 위험이 있다. 아직 키움의 원문 형식과 별도 틱 식별자를 확인하지 못했으므로 FID 20을 원장의 `received_at`이나 고유키로 사용하지 않는다.

관찰 도구에는 프로세스 내 `event_seq`와 `monotonic_ns` 출력을 더했다. 이들은 실제 수신 콜백을 구별하고 PC 벽시계가 흔들리는지 조사할 진단값이며, 증권사 고유 틱 ID나 거래소 시각의 증거가 아니다. 후속 어댑터의 중복·순서 정책은 실제 원문 사례를 확인한 뒤 결정한다. PC에서 이 추가 출력의 실증은 미실행이다.

## 실시간 관찰 도구 수동 실행과 타이머 보완 — 2026-09-26

사용자 PC에서 최초 관찰 도구 실행 후 `[GetPCIdentity] VER 3.2.0.0 build 2015.8.12`와 `observing stock trades; Ctrl+C or timeout stops subscription` 출력이 보고됐다. 이는 로그인 성공 이벤트와 `SetRealReg` 성공 반환 뒤 대기 메시지가 출력된 근거다. 실제 `주식체결` 콜백, FID 반환값, 정상 등록 해제 결과는 아직 전달되지 않았다. 해당 날짜의 관찰만으로 가격·시각 원문이나 거래소 세션을 확정하지 않는다.

도구의 관찰 타이머를 로그인 요청 전에서 실시간 등록 성공 직후로 옮기고, 종료 시 해당 종목의 `주식체결` 이벤트 수를 출력하도록 수정했다. 다음 실행에서 이벤트가 0건이면 수신값 검증은 계속 보류한다. 이 도구는 원장과 주문 경로에 연결되지 않는다. Windows 지정 PC에서 수정본의 실제 실행 검증은 아직 하지 않았다.

## KOA Studio 실시간 목록 화면 확인 — 2026-09-26

사용자가 제공한 KOA StudioSA ver 2.34 화면과 텍스트 목록에서 `실시간 목록 → Real Type : 주식체결`을 확인했다. `[20] = 체결시간`, `[10] = 현재가`, `[290] = 장구분`, `[9081] = 거래소구분`이 표시된다. FID 290·9081은 명칭만 확인했으며 값의 열거형·정규장 판정 의미는 검증되지 않았다. 같은 목록의 거래량·전일대비기호 등은 손절 입력이나 틱 식별자로 해석하지 않는다. 이는 설치 가이드의 FID 10·20 명칭과 일치하는 **정적 UI 근거**다.

화면은 `GetCommRealData`의 반환 원문, FID 10의 부호·공백·숫자 표현, FID 20의 날짜·시간대·자정 경계, 같은 시각의 여러 체결을 구별하는 ID를 보여주지 않는다. KOA Studio 버전 표시와 설치 파일 버전 표시는 서로 다른 대상이므로 동일 버전이라고 취급하지 않는다. 실시간 시세 어댑터와 손절 평가 연결은 계속 보류한다.

사용자 확인 결과, 이 정적 실시간 목록에서 FID 10·20을 선택해도 반환값 예시나 추가 형식 설명은 나타나지 않았다. 현행 저장소에서도 `GetCommRealData` 원문을 보존한 비밀값 없는 사례는 찾지 못했다. 목록을 더 탐색해 형식을 추측하지 않는다.

다음 거래일의 근거 수집을 위해 독립 스크립트 `tools/inspect_kiwoom_realtime.py`를 준비했다. Windows 3.10 32비트와 설치된 OpenAPI가 있는 PC에서 `py -3.10-32 tools/inspect_kiwoom_realtime.py 005930 --seconds 30`으로 **한 종목, 최대 30초** 수신을 관찰할 수 있다. 실행은 사용자가 지정 PC에서 별도로 수행해야 하며, 현재 환경에서는 실행하지 않았다. 로그인과 해당 종목의 실시간 등록·해제는 수행하지만 `SendOrder`/TR/계좌조회/SQLite/엔진 호출은 없다. 수신 콜백 안에서 FID 10·20·290·9081의 `repr`과 PC 수신시각을 표준출력에만 남긴다. 종목 예시 `005930`은 보유·매매 권고가 아니다. 계좌·로그인 화면은 공유하지 말고 원문 출력에서 민감 정보가 없는지 확인한 뒤 전달한다. 이 관찰값으로 거래소 타임스탬프나 틱 고유 ID가 증명되는 것은 아니다.

다음 읽기 전용 확인은 KOA Studio의 `주식체결` 실시간 데이터 **값** 화면에서 코드, FID 10, FID 20 및 수신 순서가 보이도록 원문 사례를 수집하는 것이다. 화면이 실제 이벤트 원문 대신 가공값을 표시한다면 그 차이를 기록한다. 별도 틱 ID가 제공되는지 가이드·UI에서 찾아보고, 확인되지 않으면 시각+가격을 고유 틱 키로 가정하지 않는다. 계좌·인증 정보는 수집하지 않으며 주문·정정·취소 기능은 사용하지 않는다.

## KOA 설치 자료의 실시간 체결 규격 확인 및 정규화 보류 — 2026-09-26

시작 기준은 `git fetch origin main` 뒤 `HEAD`/`origin/main` 모두
`521e993d32d6bfd50c6454d031c840fec4ce0f76`, 브랜치 `main`, 작업 트리 clean이다.

지정 PC의 설치 자료를 읽기 전용으로 확인했다. `C:\OpenAPI\KOAStudioSA.exe`와
`khopenapi.ocx`의 Windows 파일 버전은 각각 `1.0.0.1`이며 파일 수정일은 각각
2025-02-27, 2026-03-26이다. `koa_devguide.xml`의 내부 문서 버전은 **1.57**,
파일 수정일은 2026-09-12다. 문서 XML은 EUC-KR로 읽어 확인했다.
`system\koarealtime.dat`와 `system\realtime.dat`가 설치되어 있으나
`apiinitrsc.lst`가 `koarealtime.dat`를 암호화 설치 리소스로 열거한다. 해당
실시간 목록 내용을 독립적으로 판독하지는 못했다.

설치 개발가이드 1.57의 정적 근거:

- 실시간 이벤트는 `OnReceiveRealData(BSTR sCode, BSTR sRealType,
  BSTR sRealData)`이며 `sCode`가 종목코드, `sRealType`이 실시간 타입이다.
  문서는 `sRealData` 전문을 사용 불가로 표시하고, FID별 데이터는 이벤트
  콜백 중 `GetCommRealData(sCode, fid)`로 읽도록 안내한다.
- 타입 `주식체결` 예시의 FID 10은 현재가, FID 20은 체결시간이다. 같은 예시는
  FID 13 누적거래량과 FID 228 체결강도도 제시하지만 손절 가격 입력에는
  포함하지 않는다. 이 자료만으로 FID 10의 부호/문자 표현 및 FID 20의
  날짜·시간대 표현까지 확정하지 않았다.
- `SetRealReg(screen, code_list, fid_list, option)`은 실시간 등록 함수이며
  옵션 `0`은 해당 화면 등록 교체, `1`은 기존 등록에 추가로 설명되어 있다.
  문서상 한 번의 등록 한도는 종목 100개, FID 100개다. `SetRealRemove(screen,
  code)`는 종목 단위 해제 예제가 있고, `DisconnectRealData(screen)`는 해당
  화면 등록 해제를 요청하되 다른 화면에도 등록된 종목은 계속 수신된다고
  설명한다.
- 설치 입력 범례와 가이드에는 KRX 6자리 코드와 NXT `_NX`, ATS `_AL` 접미
  코드가 구분되어 있다. 현재 손절 `Quote` 계약은 6자리 코드만 허용하므로
  거래소/코드 범위는 어댑터에서 임의로 넓히지 않는다.

**구현 보류:** 현재 자료는 이벤트·FID 이름과 등록/해제 호출 경계는 확인하지만,
가격 원문을 안전하게 `Quote.price`로 정규화할 표현 규칙과 체결시각의 날짜·시간대
해석을 증명하지 않는다. 문서화된 별도 틱 고유 ID도 찾지 못했다. 따라서 동일
가격·시각의 두 이벤트가 중복인지 별개의 유효 체결인지 안전하게 판정할 수 없다.
원문·FID 값의 KOA Studio 실시간 목록 확인 또는 비밀값을 제거한 허용 자료가
필요하다. 그 전까지 실제 OpenAPI 연결, 필드 정규화, 중복 식별 및 가상 손절
전달 어댑터를 구현하지 않는다. 로그인/계좌 선택 화면이 나타날 수 있는 KOA
Studio 실행은 하지 않았으며 로그인·TR·실시간 등록도 호출하지 않았다.

기준 커밋의 `virtual_quote_status` 검사는 이미 미수신(`NO_QUOTE`), 신선
(`FRESH`), 2초 초과(`STALE`), 평가시계 역행(`CLOCK_UNCERTAIN`), 종목 간
미수신, SQLite 재시작 후 checkpoint 복원 및 조회의 revision 불변성을 다룬다.
connection과 exchange_session은 항상 `UNVERIFIED`다.

Windows Python **3.10.8 32비트** (`py -3.10-32`, 사용자 설치 환경) 검증:

| 검사 명령 | 결과 |
|---|---|
| `py -3.10-32 -m pytest -q --tb=line --basetemp <고유 임시 경로> tests/test_virtual_quote_status.py` | 종료 0, **1 passed** |
| `py -3.10-32 -m pytest -q --tb=line --basetemp <고유 임시 경로>` | 종료 0, **164 passed** (`10.68s`) |
| `py -3.10-32 -m ruff check execution contracts tests` | 종료 0, All checks passed |
| `py -3.10-32 -m ruff format --check execution contracts tests` | 종료 0, **46 files already formatted** |
| `py -3.10-32 -m execution` | 종료 0, 데모 정상 (`virtual_calls=2`, `replay_changes=0`) |
| `git diff --check` | 종료 0 |

테스트는 임시 SQLite DB를 사용했다. 로그인·계좌 선택, `SendOrder`, 정정·취소,
운영 DB 변경, 배포는 실행하지 않았다. 실시간 이벤트 수신·Disconnect 처리의
실제 서버 동작과 KOA UI 안의 현재 실시간 목록은 미검증이며, 확인된 문서 규격을
실제 체결 가격·시각 의미의 완전 검증으로 간주하지 않는다.

## 체크포인트 시세의 읽기 전용 상태 — 2026-09-26

`Ledger.virtual_quote_status(symbol, timing)`은 마지막으로 수락한 가상
시세 checkpoint를 읽어 `NO_QUOTE`, `FRESH`, `STALE`, `CLOCK_UNCERTAIN`을
표시한다. 수신 시각과 평가 시각을 반환하고 수신 이후 2초 경계 및 시계
역행을 구분한다. checkpoint의 존재는 실시간 연결·거래소 정규장이나 휴장일의
근거가 아니므로 `connection`과 `exchange_session`은 항상 `UNVERIFIED`다.
조회는 주문·손절 발동·원장 기록을 생성하지 않는다. 재시작 후 상태,
다른 종목 미수신, 오래된 시세, 역행한 시계와 읽기 전용 동작을 검증했다.

Linux Python 3.12에서 Windows 잠금을 임시 대체한 관련 테스트 **17 passed**,
잠금·프로세스 검사가 필요한 4개 파일을 제외한 회귀 **153 passed**.
Ruff 검사·포맷 및 `git diff --check` 통과. 이번 변경 이후 Windows 3.10
32비트 전체 회귀와 키움 시세 연결은 미실행이다. 기존 checkpoint는 최신값만
남기므로 이 조회는 연결 장애 이력이나 틱 전체의 감사 자료가 아니다.

## 2026-09-26 시세 입력에서 가상 평가까지의 원자 경계 — 기준 `fc6f334`

작업 시작 시 `git fetch origin main` 후 `HEAD`와 `origin/main`은 모두
`fc6f334d1d01a81d0c29223330562881079ec25b`였고 브랜치 `main`, 작업 트리는
깨끗했다. 기존의 손절 발동·청산 의무·dispatcher 재시작 차단은 재작성하지 않았다.

기존 `Quote`는 종목코드, `LAST_TRADE`, 정확한 양수 유한 decimal 가격,
시간대가 있는 수신시각을 검증하고 `ObserveAt`은 시간대가 있는 평가시각과
최대 2초(`1` 또는 `2`)만 허용한다. 순수 평가기는 다른 종목·평가시각보다
미래인 시세·2초 초과 시세를 `UNAVAILABLE`로 처리하고 2초 경계는 허용한다.
잘못된 가격과 잘못된 종목 형식은 계약 검증에서 거부된다. 기존 결함은
종목별 최근 수신/평가시각을 보존하지 않아 같은 시세·역순 시세를 재평가할
수 있었고, 발동 기록과 비교 결과를 같은 쓰기 트랜잭션에 연결한 진입 경로가
없었던 점이다.

`Ledger.process_virtual_stop_quote`를 추가했다. 검증된 새 시세의 종목별 최신
checkpoint와 손절 발동 latch를 같은 SQLite `BEGIN IMMEDIATE` 트랜잭션에서
기록한다. 시장 틱마다 outbox에 이벤트를 무한히 쌓지 않도록 checkpoint 전용
테이블에 종목별 최신 시세만 보존한다. 기존 schema v1은 v2로 로컬 마이그레이션
지원하며, 이번 작업에서는 운영 DB를 열지 않았다.
최근 수신시각보다 역순, 동일 수신시각 중복, 평가시계 역행, 미래/오래된 시세,
다른 종목은 거절하며 거절 입력은 checkpoint를 전진시키지 않는다. 가격·시세
checkpoint는 계좌·체결 사실이 아닌 단조성 검사용 로컬 가상 상태다.
기존 latch의 멱등성과 요청별 청산 의무 원장은 그대로 사용한다.

세션 값 `REGULAR`는 가상 시나리오 실행 조건일 뿐 거래소 세션의 증거로
인정하지 않는다. `VirtualDispatcher`는 `Scope.broker_adapter="virtual"`만
받고 `real_order_transport_available`은 항상 `False`다. 거래소 시간표·휴장일
근거가 없어 실제 주문 가능 상태는 계속 차단이다. 임의의 거래 시간표는
추가하지 않았다.

회귀 시나리오: 부분 매수 체결 4주 직후 보호 후보 4주, 뒤늦은 매수 체결의
추가 의무, 시세 중복·역순·평가시각 역행·미래·다른 종목, 같은 SQLite 원장
재시작, 손절 latch 멱등성, 취소 `UNKNOWN` 후 재시작/추가 제출 차단을 확인했다.
기존 계약 회귀에서 오래된 시세 및 정확히 2초 경계도 계속 검사된다. 취소
`UNKNOWN`을 성공/실패로 추정하지 않고, 자동 재주문하지 않는다.

검증은 Windows Python `3.10.8` 32비트 (`py -3.10-32`, 사용자 설치 환경)에서
수행했다. 각 종료 코드:

| 검사 명령 | 결과 |
|---|---|
| `py -3.10-32 -m pytest -q --tb=line --basetemp <고유 임시 경로> tests/test_stop_evaluation.py tests/test_virtual_stop_binding.py` | 종료 0, **27 passed** |
| `py -3.10-32 -m pytest -q --tb=line --basetemp <고유 임시 경로>` | 종료 0, **163 passed** (`9.02s`) |
| `py -3.10-32 -m ruff check execution contracts tests` | 종료 0, All checks passed |
| `py -3.10-32 -m ruff format --check execution contracts tests` | 종료 0, **44 files already formatted** |
| `py -3.10-32 -m execution` | 종료 0, 데모 정상 (`virtual_calls=2`, `replay_changes=0`) |
| `git diff --check` | 종료 0 |

프로젝트 `.venv`, `.tools/typecheck/basedpyright/index.js`와 basedpyright 명령은
없어 잠금 기반 격리 환경 및 basedpyright는 미실행이다. Windows Python 3.10
32비트 사용자 설치를 직접 사용했다. 테스트는 임시 SQLite DB이며 운영 DB는
열거나 변경하지 않았다. 키움 로그인·조회·TR·실제/모의 주문·정정·취소,
실제 세션/휴장일 확인, 배포는 실행하지 않았다.

남은 D03 완료 조건: 자동 시세 수신 어댑터와 연결 상태/오래된 시세 운영 표시,
실제 거래소 시간·휴장일에 대한 검증된 세션 근거, 부분 매도 및 추가 체결 후
청산 의무의 끝까지의 재시작 검증, 취소·거절·미체결의 증권사 근거 대조·알림,
기존 보유 인계, 실제 키움 데이터에서의 Q01~Q11 확인이다. 따라서 D03은
부분 구현이며 완료가 아니다.

## 2026-09-25 D03 전송/재시작 경계 재검토 — 기준 `1ddab20`

`VirtualDispatcher.send`의 전송 직전 SQLite 트랜잭션은 해당 stop request의 의무가
정확히 하나이며 `PENDING`인지, 같은 종목의 다른 의무에 `REVIEW_REQUIRED` 또는
`BLOCKED_EVIDENCE`가 없는지 확인한 뒤에만 `SENDING`을 기록한다. 지정된 partial fill,
cancel·reject·`UNKNOWN`, 재시작 경계에서 새 production 결함은 재현되지 않았다.
이미 구현된 누락/중복 의무 격리와 같은 종목 격리 의무 차단은 재구현하지 않았다.

회귀 보강: 부분 매도 reservation 상태에서 dispatcher 재생성 후 follow-up sell 0,
취소 `UNKNOWN` 이후 재시작 후 drain 0, 손실된 의무 원장 뒤 지연 매수·후속 의도 생성
시나리오에서 restart 후 의무 `BLOCKED_EVIDENCE`, 전송 상태 `INTENT_PERSISTED`,
가상 호출 0을 검사했다. 테스트용 의무 누락 이후의 새 의무도 차단되는 것이 기대값이며
정상 진행으로 처리하지 않는다.
production execution code는 수정하지 않았다. 회귀 테스트 변경은
`tests/test_virtual_stop_binding.py`에만 추가했다. 진행 범위와 검증 기록은 이 MD와
`docs/WORK-CONTINUATION-STATUS.md`에 기록했다.

검증: Windows Python 3.10.8 32-bit 사용자 설치 환경에서 전체 pytest **161 passed**
in 11.68s, Ruff check 통과, Ruff format check **40 files already formatted**,
`python -m execution` 가상 데모 통과, `pip check`는 의존성 문제 없음,
`git diff --check` 통과. 동시 검사 중 첫 전체 pytest 호출은 120초 도구 제한에 걸려
중간 출력에서 종료됐고, 단독·고유 basetemp 재실행은 통과했다. timeout 원인은
재현되지 않았다. 저장소 `.venv`와 basedpyright 도구는 없어 격리/고정 환경 및
type-check 검증은 미실행이다.
테스트 실패/수정 이력: 첫 확장 assertion은 손실 의무 뒤의 추가 의무를 `PENDING`으로
기대했으나 원장이 더 보수적으로 `BLOCKED_EVIDENCE`를 반환했다. 이 기대값을 수정해
정상 차단 상태를 확인했고 최종 전체 회귀가 통과했다. production 코드 변경은 없다.

키움 로그인·조회·TR·주문·체결, 운영 DB 및 배포는 실행하지 않았다. 자동 시세 수신,
검증된 거래 세션, 증권사 조회/알림 호출 및 실패 기록은 여전히 미구현이므로 D03 완료가 아니다. 공용 Telegram 송신 어댑터만 준비됐고 D03 경보에는 연결되지 않았다.

## 동일 종목의 다른 격리 의무도 전송 직전 차단 — 2026-09-25

가상 전송은 해당 요청의 청산 의무뿐 아니라 같은 종목의 모든 손절 의무를
동일 SQLite 트랜잭션에서 조회한다. 하나라도 `BLOCKED_EVIDENCE` 또는
`REVIEW_REQUIRED`이면 새 요청의 `SENDING` 사실을 기록하지 않는다.
임시 원장에서 첫 요청의 의무를 제거하고, 늦은 매수 체결 뒤 다음 손절
요청을 생성한 상황에서 다음 요청 자체는 `PENDING`이지만 전송하지 않는
것을 확인했다. 이는 정상 근거를 재확인하기 전 중복 매도를 막는 가상 검사다.

Linux Python 3.12 Windows 잠금 임시 대체 검사에서 관련 **15 passed**,
잠금·별도 프로세스 검사 파일 4개 제외 **150 passed**; Ruff 검사·포맷,
`git diff --check` 통과. 이번 변경의 Windows 전체 회귀와 실제 키움
주문·체결 검증은 아직 실행되지 않았다.

## 손절 요청과 의무의 누락·중복 대조 — 2026-09-25

손절 요청이 원장에 남아 있는데 같은 요청 ID의 청산 의무가 없으면 조회가
해당 요청을 `BLOCKED_EVIDENCE`로 노출한다. 하나의 요청에 의무가 둘 이상인
자료도 정상 진행으로 처리하지 않는다. 가상 dispatcher는 이러한 격리 상태에서
후속 매수 체결로 추가 보호 후보가 생겨도 새 매도를 만들지 않는다.
시험용 임시 SQLite 자료에서 의무를 제거한 뒤 전송 중단, 조회 격리,
늦은 매수 체결 후 추가 제출 차단을 확인했다. 조회상 미확인 체결량을
확정하지 않으며 실제 키움 계좌의 상태를 추정하지 않는다. Linux Python 3.12
Windows 잠금 임시 대체 검사에서 관련 **15 passed**, 잠금·별도 프로세스
검사 파일 4개를 제외한 회귀 **150 passed**, Ruff 검사·포맷 및
`git diff --check` 통과. 이 변경 이후 Windows 전체 회귀는 미실행이다.

## 사용자 PC 회귀 결과 전달 — 2026-09-25

사용자가 앞서 안내한 Windows PowerShell 검사 명령 실행 후 전달한 출력:
전체 pytest **161 passed in 8.97s**, Ruff 검사 **All checks passed!**,
Ruff 포맷 검사 **79 files already formatted**, `python -m execution` 가상
데모는 `managed=70`, `reserved=0`, `cancel_unknown_reserved=100`,
`cancel_confirmed_reserved=30`, `lifecycle=CANCELLED`, `virtual_calls=2`,
`replay_changes=0`을 출력했다. 이 결과는 사용자 PC에서 전달된 로그이며
이번 작업 환경에서 Windows 실행을 직접 재현한 것은 아니다. 인터프리터
비트 수, 각 명령의 종료 코드, `git status --short` 출력은 별도 전달되지
않았으므로 확정 기록하지 않는다. 실제 키움 주문·체결 조회와 운영 DB
검증으로 해석하지 않는다. D03의 자동 시세·세션·외부 조회·알림은 남아 있다.

## 전송 직전 손절 의무 근거 재확인 — 2026-09-25

가상 dispatcher는 `virtual-stop:` 요청을 전송 상태로 표시하기 직전,
동일 SQLite 트랜잭션에서 읽은 원장으로 해당 요청의 청산 의무가 정확히
한 건이고 `PENDING`인지 확인한다. 발동 기록·요청·수량의 대조 실패 또는
의무 누락 시 `SENDING` 사실을 기록하지 않으며 가상 호출도 하지 않는다.
시험용 임시 DB에서 의무 기록을 제거한 뒤 기존 요청의 전송을 시도해
`INTENT_PERSISTED` 유지와 가상 호출 0건을 확인했다.

Linux Python 3.12에서 Windows 잠금을 임시 대체한 관련 테스트 **15 passed**,
Windows 잠금·별도 프로세스 검사 파일 4개를 제외한 테스트 **150 passed**.
Ruff 검사·포맷과 `git diff --check` 통과. 실제 Windows 3.10 32비트 전체
회귀와 키움 주문·체결 근거는 미검증이며, 실제 주문 API·운영 DB는 사용하지 않았다.

## 격리된 의무의 후속 가상 매도 차단 — 2026-09-25

가상 dispatcher가 기존 손절 의무 중 `BLOCKED_EVIDENCE` 또는
`REVIEW_REQUIRED` 상태를 발견하면 새 손절 매도 요청을 생성하지 않는다.
부분 매수 체결 뒤 추가 체결로 새로운 보호 후보가 생겨도 기존 의무 근거가
격리되면 제출 전 멈추는 회귀 검사를 추가했다. 이는 가상 경계이며 실제
증권사 조회나 자동 알림을 실행하지 않는다.

Linux Python 3.12에서 `msvcrt` 잠금을 임시 대체한 관련 테스트 **14 passed**.
전체 실행은 **156 passed, 4 failed**였으며 4개 실패는 Windows 잠금/별도
프로세스 실행에 필요한 `msvcrt`가 Linux에 없는 데서 발생했다. 잠금·프로세스
검사 파일 4개를 제외한 검사는 **149 passed**. Ruff 검사·포맷과
`git diff --check`가 통과했다. Windows 3.10 32비트 전체 회귀는 미실행이다.

## 손절 발동 근거 누락 시 의무 조회 격리 — 2026-09-25

가상 손절 의무 조회에서 요청·주문·규칙 버전 외에 같은 종목·버전의 원래
손절 발동 기록도 대조한다. 기록이 누락된 원장 자료는 `BLOCKED_EVIDENCE`와
`QUERY_BROKER`로 표시하며 정상 진행으로 해석하지 않는다. 정상 부분 매도와
발동 기록 누락을 함께 검사했다. Linux Python 3.12에서 Windows 파일 잠금을
대체한 임시 모듈로 관련 테스트 **13 passed**. 실제 Windows 잠금·키움
자료·운영 DB는 검증하거나 변경하지 않았다.

## 취소된 손절 매도의 자동 재제출 차단

손절 매도 의무의 기존 요청이 취소 완료되어 예약이 풀려도, 정규장
dispatcher 호출이나 재시작 후 같은 발동을 근거로 잔량을 자동 제출하지
않도록 했다. 의무 조회는 `REVIEW_REQUIRED` / `REVIEW_AND_ALERT`, 확인된
미체결 수량과 해제된 예약량을 표시하며 운영자 검토 전에는 새 매도를
생성하지 않는다. 취소 확인은 손절 의무의 충족을 의미하지 않는다.

가상 SQLite 검사에서 손절 매도 전량 취소 후 의무 잔량·예약량, 재차
dispatcher 호출과 새 dispatcher 재시작 모두 추가 제출이 없는지 확인했다.
Python 3.10.8 32비트에서 관련 테스트 **13 passed**, 전체 pytest **156
passed**, Ruff 검사·포맷 확인, 가상 데모와 `git diff --check`가 통과했다.
이는 로컬 가상 검사이며 실제 증권사 조회, 알림, 취소 후 운영 정책 연결은
구현하지 않았다.

## 후속 검증: 실패 사유 조회

`virtual_stop_obligations` 결과에 `failure_reason`을 추가했다. 증권사 거절
또는 명시적 전송 실패가 원장에 기록되어 `REVIEW_REQUIRED`인 경우에만
해당 요청의 실제 기록된 사유를 읽는다. 근거가 충돌해 `BLOCKED_EVIDENCE`이면
사유를 임의로 고르지 않는다. 가상 거절은 전송 시도 기록 뒤에만 받아들이는
원장의 규칙에 맞춰 시험했다. Linux 임시 fixture 관련 pytest **12 passed**,
Ruff 및 `git diff --check` 통과. 실제 알림 전송과 증권사 상태 조회는
아직 연결하지 않았다.

## 2026-09-24 주문 실패 대응 정책 반영

사용자는 손절 시장가 매도가 거절되거나 전송 실패한 경우 자동 재주문을 멈추고,
증권사 상태를 조회한 뒤 남은 수량과 사유를 알리는 정책(1번)을 선택했다.
기존 가상 dispatcher의 동일 종목 매도 실패·거절 후 자동 재주문 차단을
재시작 포함 테스트로 확인했다. `StopObligationView.next_action`은 완료 시
`NONE`, 확인이 필요한 실패·거절·취소 시 `REVIEW_AND_ALERT`, 그 밖의
미완료·증거 불확실 상태에서 `QUERY_BROKER`를 반환한다. 이는 조회 전용
표시이며 실제 증권사 조회나 알림 전송을 실행하지 않는다. 부분체결 2주와
남은 2주, 명시적 미전송 실패 후 남은 2주를 각각 검사했다.

Linux Python 3.12 임시 Windows 잠금 대체 fixture의 관련 pytest
**11 passed**, Ruff 및 `git diff --check` 통과. Windows 3.10 32비트
전체 검사, 키움 주문·체결 조회 연동, 사용자 알림 경로 및 미체결 판단
시간은 아직 검증·구현하지 않았다. 기존 보유는 확인된 원가·수량·규칙의
인계 정책이 정해질 때까지 가상 보호 대상에 편입하지 않는다.

## 후속 검증: 의무 상태 조회

`Ledger.virtual_stop_obligations(symbol)`은 의무별 원래 수량, 확인된 매도
체결량, 남은 수량, 현재 예약량과 상태를 원장 사실에서 읽는다. 부분체결
중에는 `PENDING`, 모두 확인되면 `FULFILLED`, 증거 충돌·재대조·매도
`UNKNOWN`에서는 `BLOCKED_EVIDENCE`, 거절·명시적 전송 실패·취소는
`REVIEW_REQUIRED`로 표시한다. 이 조회는 새 매도 주문이나 자동 재시도를
생성하지 않는다. Linux 임시 fixture에서 관련 pytest **10 passed**,
Ruff와 `git diff --check` 통과. Windows 3.10 32비트 전체 회귀·키움
자료 검증은 수행하지 않았다. 의무 상태를 운영 주문 정책과 연결하는 작업은
아직 남았다.

## 후속 검증: 요청별 청산 의무 기록

가상 손절 매도 요청을 원장에 새로 수락할 때 `StopSellObligation`을 같은 SQLite
트랜잭션에 한 건 기록한다. 요청 ID, 주문 ID, 종목, 보호 수량, 발동 규칙 버전을
고정하며 동일 요청 재처리에서는 새 의무를 만들지 않는다. 기존 부분체결로
예약 중인 수량에는 추가 의무를 만들지 않고, 늦은 매수 체결로 새로 생긴
보호 수량만 별도 요청·의무로 기록한다. 매도 부분체결 뒤에도 원래 의무의
요청 ID와 최초 보호 수량은 보존된다. 기존 원장 테이블의 범용 journal에
새 이벤트 종류를 기록하므로 이 작업에서 운영 DB를 이전하지 않았다.

변경 파일: `execution/models.py`, `execution/storage.py`, `execution/ledger.py`,
`tests/test_virtual_stop_binding.py`. Linux Python 3.12의 임시 Windows 잠금
대체 fixture에서 관련 pytest **10 passed**, Ruff와 `git diff --check` 통과.
이는 Windows 계좌 잠금이나 전체 회귀 검사가 아니다. 청산 의무의 동적
잔량·완료·취소·거절 상태와 증권사 조회 근거 연결은 후속 단계이며 실제
주문 가능 상태를 뜻하지 않는다.

## 2026-09-24 후속 변경: 가상 매도 요청의 손절 발동 연결

`New.stop_latch_version`을 선택적 양의 정수로 추가했다. 가상 손절 dispatcher는
시장가 매도 요청에 실제 원장에 저장된 손절 발동의 규칙 버전을 기록한다.
`Ledger.submit`은 같은 종목·규칙 버전의 발동 기록이 없으면
`STOP_LATCH_LINK_NOT_FOUND`로 요청 전체를 거절한다. 매수와 지정가 주문에
손절 발동 버전을 붙이는 것도 거절한다. `virtual-stop:` 요청 키에 연결
버전이 빠지거나, 연결 버전에 손절 요청 키가 없을 때도 거절한다. 따라서 재시작 후 `Request`의 종목,
수량, 주문 ID, `stop_latch_version`을 발동 사실과 대조할 수 있다. 기존의
버전 표시가 없는 요청은 마이그레이션 없이 그대로 읽지만, 연결 근거가
있는 신규 손절 요청으로 소급 해석하지 않는다.

변경 파일: `execution/models.py`, `execution/ledger.py`, `execution/virtual.py`,
`tests/test_virtual_stop_binding.py`. Linux Python 3.12에서 Windows 계좌 잠금
대신 임시 fixture를 쓴 관련 pytest **9 passed**, Ruff 및 `git diff --check`
통과. Windows 잠금과 전체 회귀는 아직 미실행이다. 이 연결은 가상 손절
매도 요청과 발동 기록의 **추적 근거**이며, 독립된 청산 의무의 생성·완료
원장이나 자동 시세 감시·실제 거래 세션 증거는 아니다. 각 추가 매수 체결에
대한 별도 청산 의무와 요청 간 1:1 대조는 후속 구현이 필요하다.

- 기준: `main`의 D01 계약과 `docs/NEXT-DEVELOPMENT-PLAN.md`
- 상태: **부분 구현**. 규칙 저장·부분체결 연결·가상 보호 후보 계산, 고정 가격·원가 비율 손절 발동 기록, 정규장 가상 시장가 매도 예약과 dispatcher 인계를 검증했다. 자동 시세 수신·실제 세션 판정·증권사 주문 연결은 미완료다.

## 이번 범위

사용자 확정 정책(2026-09-24): 최근 체결가가 **수신 시각 기준 2초 이내**인 경우만 손절 판정에 사용한다. 지연 허용값으로 3초 이상을 입력하면 계약에서 거절한다. 기존 보유의 원가 또는 부분 매도 후 잔여 원가가 확인되지 않으면 **새 비율 손절 발동을 차단**한다. 이미 적법하게 발동한 규칙의 남은 보유 보호는 유지한다. 가상 손절 매도 제출은 정규장에 한한다. 거절·실패 후 자동 재주문은 금지한다. 실제 세션 판정과 미체결 판단 시간은 아직 미정이다.

`contracts/stop_evaluation.py`는 확인된 보유 수량, 손절 관측, 기존 매도 예약, 미확정 매도 및 재대조 상태에서 **추가 보호 후보 수량**을 계산한다. 부분 매수 체결 4주에는 4주 후보, 4주 매도 예약 뒤에는 0주, 추가 매수 체결로 7주가 되면 3주 후보를 반환한다. 평가 당시 보유 수량과 원장 보유 수량이 다르면 차단한다. 매도 결과가 `UNKNOWN`이거나 재시작 후 대조가 필요하면 추가 후보는 0주로 차단한다. 이 결과는 주문 의도가 아니며 주문 전송 권한도 아니다.

사용자 결정: 손절 시세는 **최근 체결가**, 평균 매수가는 **확인된 매수 체결가의 수량 가중평균(수수료 제외)**, 첫 가상 손절 주문은 **시장가 우선**이다. 시세 모델은 최근 체결가만 받으며, 평균 계산은 비유한 가격과 빈 체결 목록을 거절한다. `execution.facts.Fill`에 선택적 정확한 체결 가격을 추가했다. 기존 가격 없는 사실은 그대로 읽되, 가격이 하나라도 없는 매수 주문의 평균은 알 수 없음(`None`)으로 남긴다. 여러 주문의 가격이 모두 확인되고 동일한 보호 규칙 버전이 붙어 있으며 기존 보유 수량·매도 체결·수량 불일치가 없을 때만 `confirmed_stop_cost_basis`가 보유분 가중평균을 계산한다. 매도 체결 후의 평균과 이전 보유의 원가는 아직 근거가 없어 `None`으로 남긴다. 시장가 손절 주문도 아직 생성하지 않는다.

## 검증

2026-09-24 발동 유지 정책: `latch_virtual_price_stop`과 `latch_virtual_cost_stop`은 확인된 보유·규칙 버전·2초 이내 시세(비율 규칙은 확인된 체결 원가까지)로 발동 사실을 종목별 한 번 기록한다. 중복 호출과 재시작은 같은 기록을 읽는다. `virtual_latched_stop_candidate`는 남은 수량과 매도 예약을 다시 계산해 늦은 매수 체결도 포함한다. 신규 매수 제출과 미전송 매수의 가상 전송을 차단하며 매도 `UNKNOWN` 또는 재대조 필요 상태에서는 추가 후보를 차단한다. `VirtualDispatcher.drain_virtual_stop`은 호출자가 정규장이라고 지정할 때만 후보를 시장가 DAY 매도로 원장에 예약하고 가상 전송한다. 같은 수량의 중복 예약은 원장의 제출 검증이 차단한다. 기존 전체 청산 스위치가 켜져 있으면 그 경로가 매도를 담당한다. 매도 실패·거절은 자동 재시도하지 않는다. **세션 값은 호출자의 주장일 뿐 거래소 시간의 검증 근거가 아니며, 자동 감시와 실제 주문 API는 연결되지 않았다.** 발동 기록과 예약된 매도를 별도의 사실로 보존한다. Linux 임시 fixture의 관련 검사 **28 passed**, Ruff 통과. Windows 전체 회귀는 미실행이다.

2026-09-24 추가 작업: `virtual_cost_stop_candidate`는 원장 한 번 읽기에서 비율 손절 판정과 관리 수량·기존 매도 예약을 합쳐 추가 보호 후보를 반환한다. `virtual_price_stop_candidate`는 가격 없는 매수 체결에도 배정된 고정 가격 손절 규칙과 실제 보유 수량을 사용한다. 확인된 부분 매도 후에도 동일 규칙 버전의 잔여 보유만 평가하고, 서로 다른 규칙 버전·기존 보유·수량 불일치에서는 보류한다. `UNKNOWN` 매도와 재대조 필요 상태는 `SELL_EVIDENCE_UNRESOLVED`로 차단하고 오래된 시세는 후보를 만들지 않는다. 이 두 API는 **주문 의도나 보호 의무를 생성하지 않는 조회 전용 결과**다. Linux 임시 fixture에서 관련 계약·원장 검사 **26 passed**, Ruff 통과. Windows 파일 잠금·전체 회귀·실제 키움 검증은 미실행이다.

후속 로컬 작업: `Ledger.observe_virtual_cost_stop`은 재시작 후 원장에서 확인된 비용 근거와 매수 체결에 배정된 비율 손절 버전을 연결한다. 신선한 최근 체결가가 역치 이하일 때만 `TRIGGERED`를 반환한다. 가격 누락·기존 보유·매도 체결 시 `COST_EVIDENCE_INCOMPLETE`, 시세 지연 시 `QUOTE_NOT_FRESH`를 반환한다. 이는 가상 판정이며 청산 의무·주문은 생성하지 않는다. Linux 임시 fixture의 관련 6개 검사와 Ruff가 통과했다. Windows 전체 검사는 실행하지 않았다.

`Ledger.apply_virtual_stop_config`는 기존 가상 설정 버전을 확인하고 규칙과 새 버전을 하나의 SQLite 트랜잭션에 기록한다. `virtual_stop_binding`은 현재 버전과 일치하는 규칙만 읽는다. 기존 숫자 설정만 있는 버전은 규칙이 없는 것으로 처리한다. 저장만으로 감시나 주문이 시작되지 않으며 외부 설정 명령의 인증·승인 경로는 연결하지 않았다. 기존 가상 설정 기준 버전은 1이다.

확인된 가상 매수 `Fill`이 원장에 반영될 때, 그 주문의 `config_version`에 해당하는 규칙이 있으면 같은 SQLite 트랜잭션에 `StopRuleAssignment`를 기록한다. 키는 체결 이벤트 ID이며 체결 수량과 규칙 버전을 보존한다. 중복 체결은 원장 멱등 처리로 재기록되지 않는다. 나중에 현재 설정 버전이 바뀌어도 이미 접수된 매수 주문의 체결은 주문 당시 규칙 버전으로 연결한다. 규칙이 없던 기존 주문의 체결은 임의의 규칙을 붙이지 않는다. 이 기록은 청산 주문 의무나 감시 활성화가 아니다. 평균 매수가 비율 손절은 체결 가격 근거가 여전히 없어 실제 평가·실행을 차단한다.

추가 원장 검사: Linux 임시 테스트 fixture에서 Windows 전용 `msvcrt` import를 대체하고 lease를 수동 활성화해 SQLite 재시작 복구·버전 불일치 롤백·잘못된 규칙 거절, 부분체결과 중복 체결의 규칙 버전 보존, 매수 주문별·매도 전 보유분 가중평균 및 가격 없는 체결·기존 보유·매도 후 계산 차단을 검증했다. **6 passed**. 이 fixture는 Windows 계좌 잠금 동작을 검증하지 않는다.

Linux에서 Windows 전용 공통 `tests/conftest.py`를 사용하지 않도록 관련 테스트 두 파일을 임시 디렉터리에서 실행했다. `PYTHONPATH=/tmp/cherrypulse-test-deps:. python -m pytest -q /tmp/cherrypulse-contract-check`: **18 passed**. `ruff check contracts tests/test_settings_contract.py tests/test_stop_evaluation.py`: **통과**. `git diff --check`: **통과**. 임시 도구 경로와 복사한 테스트 디렉터리는 이 작업 환경에만 해당한다.

## 아직 필요한 연결과 결정

1. 원하는 설정 명령의 인증·수락과 로컬 가상 설정 적용을 연결하고, 보유분의 규칙 버전을 체결 시점에 고정하여 원장에 기록한다. 현재 원하는 설정의 `ACCEPTED`는 감시 시작을 뜻하지 않는다.
2. 원가가 없는 기존 보유와 부분 매도 후 비율 손절은 차단한다. 원가 인계가 별도로 검증되기 전 이를 활성화하지 않고, 규칙 버전 변경 중 보유분의 적용 정책을 정한다. 같은 틱·이벤트 재처리 시 청산 의무가 중복 생성되지 않도록 한다. 기존 가상 청산 스위치와 신규 손절 의무의 관계도 명시한다.
3. `UNKNOWN` 해소는 증권사 조회 근거에 따르며, 재시작 직후 보유·주문 대조 전 자동 매도를 차단한다. 실제 키움 주문 API는 연결하지 않는다.
4. 최근 체결가의 최대 허용 지연은 2초, 주문 제출 세션은 정규장만으로 확정했다. 시장가가 거절되거나 체결되지 않을 때의 행동과 정확한 세션 경계를 검증해야 실제 감시와 주문을 활성화할 수 있다.

2026-09-24 해당 작업 당시 Windows 3.10 32비트 전체 회귀 검사와 키움
실증은 수행하지 않았다. 운영 DB 변경과 배포도 수행하지 않았다. 현재
회귀 재검사 결과는 아래 2026-09-25 기록을 따른다.

## 2026-09-25 회귀 재검사

저장소의 현행 코드에서 사용자 설치 Python 3.10.8 32비트로 전체 pytest
**159 passed**, Ruff 검사·포맷 검사와 `python -m execution` 가상 데모가
통과했다. `pip check`도 통과했다. 이번 작업공간에는 격리 `.venv`가 없어
사용자 site-packages를 사용했으므로 고정 잠금 환경 재현 검사는 아니다.
실제 키움 로그인·조회·주문·체결, 운영 DB 및 배포는 수행하지 않았다.

## 2026-10-12 사용자 결정 반영

30초 안에 체결되지 않은 손절 시장가 주문은 운영자 경고·수동 검토로 두고 자동 재주문하지 않는다. 전송 결과가 `UNKNOWN`이면 주문·체결·잔고 대조 전 재주문하지 않는다. 보호 실행 불가/미완료, 시세 중단 1분, 30초 이상 오래된 시세, 세션 밖 보호 대상, 5분 이상 미해결 주문, 원장·잔고 불일치를 알림 조건으로 삼는다. 상태 변경 시 즉시 알림, 같은 상태는 10분 간격 3회 뒤 30분 간격으로 완화하며 운영자 확인 시 중단한다. Telegram을 채널로 선택했으며 공용 송신 어댑터는 준비됐지만 D03 경보 호출·실패 상태 기록은 미연결이다.

기존 보유 자동 편입은 금지한다. 사용자가 종목별 수량·원가·규칙 버전을 명시 배정해야 보호 대상으로 편입한다. 불명확한 주문·잔고는 격리 표시하고 수동 확인 전 주문을 차단한다.

이 정책은 계약 결정이며 자동 시세·알림·키움 주문/조회 어댑터 구현이나 실증 결과가 아니다.
