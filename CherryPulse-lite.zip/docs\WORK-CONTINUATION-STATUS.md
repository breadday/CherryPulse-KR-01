# CherryPulse-KR-01 개발 이어가기 기록

## 2026-10-13 FID 실패 분기·아침 예약

- 배치가 실패해도 Done을 찍던 문제를 고쳤다. PowerShell 끝에
  `exit $LASTEXITCODE`를 붙여 Python 종료 코드를 살리고, 0이 아니면
  FAILED 안내(시각 범위·로그인 타임아웃)를 찍는다. 야간 검증에서 FAILED
  경로·종료 코드 1을 확인했다. 당일·8시간 제한은 손대지 않았다.
- 작업 스케줄러 `CherryPulseFIDMorning`을 등록했다. 2026-10-14 07:00 1회,
  사용자 로그인 세션(Interactive)에서 배치 실행. 등록 시 수집 스크립트는
  실행하지 않았다. 상태 Ready 확인.
- 다음: 아침 실행 → txt 민감정보 제거 → FID 원문 대조.

## 2026-10-13 FID 배치 수정·체인 검증

- 초판 배치가 한글+UTF-8 무BOM이라 cmd 파서가 깨져 즉시 종료됐다. 영문판으로
  교체했고, 파이프 `^` 이스케이프가 문자 그대로 넘어가던 것도 벗겼다(따옴표
  안에서는 불필요).
- 체인 검증(22시, 수집 거절 시각대): 배치 실행 → 도구 기동 → 문서대로
  `start time must be later today and within eight hours` 거절 → 바탕화면
  txt 생성(1174B) → 정상 종료. 파이프·리다이렉트·파일 기록 전부 동작 확인.
  남은 건 거래일 아침 실실행뿐이다.

## 2026-10-13 FID 아침 배치·PyQt5 준비

- `run-fid-morning.bat`을 만들었다. 더블클릭하면 32비트 Python으로
  `inspect_kiwoom_realtime.py 005930 --start-at 09:05 --seconds 120`을
  실행하고 바탕화면에 날짜별 txt를 남긴다. 주문·TR은 없다. 내장 PowerShell
  구문 파싱 오류 0건을 확인했으나 실제 로그인·수집 실행은 하지 않았다.
- 아침 실행 전제 조건으로 PyQt5 5.15.11을 설치했다(import·32비트 확인).
  없으면 로그인 창 단계에서 실패하므로 미리 넣었다.
- 다음: 거래일 아침 실행 → txt 민감정보 제거 → FID 원문 대조.

## 2026-10-13 병렬 작업 통합·QB1 복구·probe 정리

- 같은 작업 공간의 병렬 커밋 3건(6733b35·2822772·05e1106: 일반 매도 계약·
  trading_date·폴링·Telegram)을 확인했다. 비밀값 하드코딩은 없다(env만).
  그쪽 파일의 Ruff 진단은 그쪽 범위로 남기고 손대지 않았다.
- 병렬 편집이 QB1 리플레이 `New`의 `expires_at`을 빠뜨려 suite가 빨개졌고,
  동일 리터럴에 만료를 추가해 복구했다. `test_realtime_probe.py` 기존 Ruff
  19건은 해소했다(Qt 실명 3건만 `noqa`, 테스트 둘로 분리, 파손 1건 복구).
- 검증: 전체 pytest **182 passed**, 내 파일 Ruff check·format 통과,
  `git diff --check` 통과. D08 TBD 질문지는 2026-10-12 정책 결정으로
  불필요해져 만들지 않았다. 키움·운영 DB·배포는 실행하지 않았다.
- 변경 파일은 `tests/test_realtime_probe.py`,
  `tests/test_virtual_buy_qb.py`, 이 기록과 `docs/D03-...`,
  `docs/D05-...`뿐이다. 다음: 물리 모바일, FID 원문 대기.

## 2026-10-13 D08 정책 코드와 알림 어댑터

- `sync/polling.py`에 5초 정상 주기, 3초 요청 제한값, 5초~5분 백오프,
  성공 복귀와 4xx 운영자 확인 상태를 표현하는 순수 분류 함수를 추가했다.
- `notifications/telegram.py`에 환경변수 기반 Telegram 송신 어댑터를 추가했다.
  토큰과 응답 본문은 오류에 노출하지 않으며, 알림 호출자·재시도·실패
  상태 기록은 연결하지 않았다.
- D03/D05/D08 및 재구축 계획 문서의 구현 상태를 이에 맞게 갱신했다.
- Python AST 구문 검사와 `git diff --check`가 통과했다. 엔진 테스트, Telegram 네트워크 전송,
  Supabase·운영 DB 연결, 키움 조회/주문, 배포는 수행하지 않았다.

## 2026-10-12 D05 일반 매도 결정 반영

- 사용자가 D05-1~5를 확정했다: +5%/+10% 목표수익 알림(수동 제출 전용),
  당일 15:10 1회 시간 알림, 전량 기본/50% 부분, 지정가·현재가 기본 및
  확인 후 시장가, 당일 유효·IOC/FOK 금지, 60초 미체결 취소 뒤 수동 검토,
  자동 재주문 금지, 손절 우선.
- `contracts/sell_evaluation.py`를 추가했다. 목표수익 가격 관측과 명시된
  수동 매도 선택의 사전 안전 검사를 수행하지만 원장 주문 명령·dispatcher
  호출·알림 송신은 하지 않는다. 홀수 보유 수량은 HALF 선택을 차단한다.
- D05 계약, 정책 현황, 미확인 사항 및 시나리오 기대표를 갱신했다. +5/+10
  알림 영속 중복 방지 단위, 15:10 스케줄러, Telegram 전송 연결은 미구현.
  수익률은 평균 매수가 대비 가격 변화로 표시하고 수수료·세금 순수익으로
  가장하지 않는다.
- Telegram을 D03/D08 운영 알림 채널로 선택했다. 봇 채팅에서 `/start`만
  보내는 것은 앱 연동이 아니며, 활성 송신기와 안전한 로컬 token/chat ID
  설정이 필요하다. 봇 토큰은 문서/원장/채팅에 넣지 않는다.
- 문서/코드 구문 검증 후 엔진 테스트 가능 여부를 확인한다. 실제·모의 주문,
  키움 로그인·조회, Supabase/운영 DB, Telegram 외부 전송, 배포는 수행하지
  않는다.

## 2026-10-12 D03/D08 정책 반영 및 D05 날짜 경계

- 사용자가 D03-1~3, D08-1~5를 결정했다. 손절 30초 미체결·수동 검토,
  기존 보유 명시 배정, 시세/원장 경고 조건, Supabase Auth/RLS 소유자 권한,
  5초 폴링/재시도, 순번·expected_version 충돌, outbox ACK/보존을
  `D03-VIRTUAL-STOP-PROGRESS.md`, `D08-POLLING-CONTRACT.md`,
  `D08-SYNC-DECISIONS.md`에 반영했다. 알림 채널·수신자는 입력되지 않아
  외부 알림 연결은 보류한다.
- D05에 `Fill.trading_date`와 `Ledger.filled_buy_qty_on()`을 추가해 당일
  매수량을 명시 거래일로 집계한다. 거래일 누락/구형 fill은 추정하지 않고
  fail-closed 오류로 차단한다. Q12 가상 매수 명령은 15:20 `expires_at`을
  포함하며 기존 submit/send freshness 검사를 통과해야 한다.
- 일반 매도는 손절과 분리한 비활성 계약 경계를 추가했다. 트리거·수량·가격·
  세션·미체결 응답은 사용자 결정 전 미평가/미주문 상태다. 남은 입력은 일반
  매도 상세와 외부 알림 채널·수신자다.
- Python 코드와 기존 QB scenario 입력을 수정했으나 테스트/정적 실행은 하지
  않았다. `git diff --check`만 수행했다. 실/모의 주문, 키움, 운영 DB,
  Supabase 연결, 외부 알림, 배포, 커밋·푸시는 하지 않았다.

## 2026-10-12 진행 현황 대조 및 D08 결정 질문서

- 시작 기준: `main...origin/main`, 작업 트리 clean. 개발방향 → 재구축 계획 →
  계약 → 테스트 매트릭스 → 미확인 사항 순서와 최신 D01~D08 진행 기록을
  대조했다. 기존 Q12는 이미 13건 모두 확정되어 있으므로 다시 묻지 않는다.
- 현재 단계별 판정과 다음 순서는
  [`PROJECT-STATUS-AND-DECISIONS.md`](PROJECT-STATUS-AND-DECISIONS.md)에,
  D08-1~5 선택지는 같은 문서 질문서에 정리했다. 재구축 계획의 REBUILD-01~07
  요약 상태도 현 기록에 맞게 갱신했다.
- 다음 개발은 D08 세부 결정 답변 뒤 폴링 계약 확정 → 비밀값/운영 DB를 쓰지
  않는 로컬 가상 동기화 구현이다. 응답 전에는 임의 주기·RLS·충돌 정책을
  코드화하지 않는다. 답변과 무관한 D05 세션 경계 및 D03 가상 검증은 계속
  진행할 수 있다.
- 이번 변경은 문서만 수정했다. 코드 검사·엔진 테스트는 실행하지 않았다.
  실제/모의 주문 API, 키움 로그인·조회, 운영 DB, 배포, 커밋·푸시는 하지 않았다.

## 2026-10-11 남은 개발 정리·동기화 계약

- 가능한 범위를 전부 반영했다: D08 폴링 동기화 계약 문서
  (`D08-POLLING-CONTRACT.md`, TBD 5건은 결정 전까지 코드 차단).
  Node **23 passed**, pytest **181 passed, 4 subtests passed**, 데모 정상,
  diff clean. 키움·운영 DB·배포는 실행하지 않았다.
- 아래 입력 없이는 진행 불가하며 값을 지어내지 않는다.

| 차단 항목 | 필요한 입력 | 제공자 |
|---|---|---|
| D02 물리 모바일 | iOS·Android 실기기 6/6 + 기종·OS | 사용자 (망 분리로 차단 중) |
| D01/D08 TBD 5건 | 폴링 주기·충돌 해결·Auth/RLS·서버 순번·단절 알림 | 사용자 결정 |
| D08 연동·실키 | Supabase 프로젝트·키, 네트워크, 계정 | 사용자 (비밀값은 저장소 금지) |
| D03 어댑터 | 장중 FID 10·20 원문+순번 (거래일 실행) | 사용자 (도구 대기 중) |
| D06 Q01~Q11 | 읽기전용 수집 결과, opw00007 규격 | 사용자 |
| D07/D09/D10 | 지정 PC·계좌, 운영 정책, 배포 승인 | 사용자 (별도 명시 지시) |

## 2026-10-11 D05 확장·D08 결정

- D05 확장을 구현·검증했다: 당일 재진입 차단(원장 날짜 없이 호출자 누적량),
  명시 만료 강제. 신규 포함 QB **4 passed**, 전체 **181 passed**,
  Ruff 통과. 상세는 `docs/D05-BUY-PROGRESS.md`에 있다.
- D08 결정을 기록했다(Supabase / Supabase Auth / 폴링):
  `docs/D08-SYNC-DECISIONS.md`. 비밀값 없음, 구현 미착수. 키움·운영 DB·
  배포는 실행하지 않았다.
- 다음: 폴링 동기화 계약 문서, 물리 모바일, FID 원문 대기.

## 2026-10-12 실브라우저 검증·캐시버스터

- `c60994f` 캐시버스터 1줄이 `main`에 있다. Codex 검증과 자체 재실행이
  일치했다: Node **23 passed**, pytest **180 passed, 4 subtests passed**,
  데모 정상, diff clean, Ruff 기존 1파일만. 실브라우저(PC Chrome)
  6/6 Pass. 변경 파일은 이 기록과 `docs/D02-BOARD-PROGRESS.md`뿐이다.
- 다음: 물리 모바일(iOS·Android 실기기) → D02 기록 → D01/D08 서버 동기화.

## 2026-10-11 비보안 오리진 저장 수정

- PC 화면 검증에서 `crypto.randomUUID is not a function`으로 매수·손절
  패턴 저장이 전부 실패함을 콘솔로 확인했다. 비보안 LAN 오리진이 원인이다.
  `newDraftId()` 폴백을 추가하고 호출 3곳을 교체했다. 변경 파일은
  `web/board/board.js`, `web/board/board.test.js`, 이 기록과
  `docs/D02-BOARD-PROGRESS.md`다.
- 검증: Node 보드 **23 passed** (신규 폴백 1 포함), `node --check`,
  `git diff --check` 통과. Python 회귀는 지정 PC에서 재실행한다.
  같은 LAN 주소에서 저장 재확인이 남았다. 키움·운영 DB·배포는 실행하지
  않았다.

## 2026-10-11 물리 모바일 확인 차단

- 실기기 확인이 망 분리(PC·폰 서로 다른 네트워크, 같은 와이파이 불가)로
  차단됐다. 체크리스트 결과란은 미기입 유지, 정적 6/6 Pass만 유효하다.
  D02 모바일 항목은 pending 유지.
- 다음 후보: D01/D08 서버 동기화 준비(Q12 방식의 결정 질문지부터).

## 2026-10-11 토글 44px 패치

- 체크리스트 6번 대조에서 토글 2종의 계산 높이가 약 35px임을 확인하고
  `web/board/styles.css`에 `min-height:44px` 1줄을 추가했다. Node 보드
  **22 passed**, `git diff --check` 통과. 정적 6/6 Pass, 실기기 pending
  유지. 키움·운영 DB·배포는 실행하지 않았다.

## 2026-10-11 D02 모바일 체크리스트 고정

- `docs/D02-MOBILE-CHECKLIST.md`를 만들었다. 6항목 × 2기기(iOS Safari,
  Android Chrome)이며 기준은 보드 마지막 변경 9d6599b다. 초안의 "종목 카드
  매수 문구 표시" 불릿은 구현과 모순(매수는 손절 select에서 제외됨)이라
  "매수 연결 UI 없음"으로 고쳤고, kind 노출 표현도 화면 문구 기준으로
  바꿨다. 실기기 확인 전이며 결과는 기입되지 않았다.
- 다음: 실기기 6/6 Pass 확인 → D02 진행 기록 → D01/D08 서버 동기화.

## 2026-10-11 D05 QB1·QB2 가상 검증

- Q12 확정값으로 매수 가상 시나리오를 구현·검증했다. 새 파일은
  `contracts/buy_evaluation.py`(순수 평가기, 주문·전송 없음)와
  `tests/test_virtual_buy_qb.py`(QB1 체결·QB2 취소·평가기 경계)다. 기존
  원장·dispatcher 계약을 재사용했고 새 전송 경로·주문 API는 없다.
- 검증: 신규 **3 passed**, 전체 pytest **180 passed, 4 subtests passed**
  (`7.84s`), 관련 파일 Ruff check·format 통과, `git diff --check` 통과.
  상세와 실행 로그는 `docs/D05-BUY-PROGRESS.md`에 있다. 키움·운영 DB·
  배포는 실행하지 않았다.
- 남은 D05: 전량 청산 후 당일 재진입, 만료 강제, D01 인증 연결. D02 물리
  모바일, D03 세션·실시세, D06·D07은 계속 차단·대기다.

## 2026-10-11 D02 매수 폼 구현·검증

- Q12 확정 스펙으로 매수 패턴 폼을 바닐라 JS로 구현했다. TSX 초안은
  저장소에 빌드 파이프라인이 없어 채택하지 않았고, 목표가 기반 예상가
  계산(6.1 위반)과 `execution_configs` 미리보기 명칭(경계 혼동)은 제외·
  개명했다. 변경 파일은 `web/board/index.html`, `web/board/board.js`,
  `web/board/board-backup.js`, `web/board/board.test.js`, 이 기록과
  `docs/D02-BOARD-PROGRESS.md`다.
- 검증: `node --test` **22 passed**, `node --check` 4파일,
  `git diff --check` 통과. 첫 실행 신규 2건 실패(하네스 id 미등록)는
  기존 관례(id 등록)대로 수정 후 재통과했다. Python 전체 회귀는 지정
  PC에서 재실행한다. 키움·운영 DB·배포는 실행하지 않았다.
- D02 남은 조건은 지정 모바일 물리 확인과 D01/D08 서버 동기화다. 다음은
  D05 QB1·QB2 가상 시나리오 검증이다.

## 2026-10-11 Q12 확정·계약 반영

- Q12 질문지의 제안 13건이 사용자 확정 13건으로 승격됐다. 2.2 근거는
  "사용자 판단(특정 라인 근거 없음)"으로 정정했고, 6.1은 B(-3%) 고정으로
  택1했다 (A 선택지는 D05 확장으로 미룸).
- 반영 문서: `REBUILD-02-Q12-DECISION-QUESTIONNAIRE.md`(확정 표시),
  `REBUILD-02-CONTRACTS.md`(Q12 매수 패턴 계약 절),
  `REBUILD-02-TEST-MATRIX.md`(QB1 체결·QB2 미체결 문서 시나리오),
  `D02-BOARD-PROGRESS.md`(매수 폼 스펙, 미구현). 엔진·보드 코드는
  건드리지 않았다.
- 다음 순서: 매수 폼 구현(스펙 기준) → D05 조건·주문 계약의 가상 시나리오
  검증. D01 실인증, FID 원문·세션, D06 읽기 근거, D07 실제 주문, 물리
  모바일은 계속 차단·대기다. 실/모의 주문 API·운영 DB·배포는 별도 명시
  지시 없이 수행하지 않는다.

## 2026-10-11 D02 입력 길이 검증·문서화·반영

- 시작 기준: fetch 후 `HEAD`/`origin/main` 모두
  `db82302e8277b4dbf78ceb62a2f2690e04e8b9a4`, `main`, 시작 시 clean.
  사용자 지시로 가능한 개발은 완료·문서화하고, 불가능한 것은 문서로 남긴 뒤
  커밋·푸시·반영까지 진행한다.
- D02 보드의 종목 등록·수정, 손절 패턴 생성·새 버전 입력에 길이 검증을
  추가했다 (종목명 100자·메모 1000자·링크 2048자·패턴명 100자).
  가져오기·백업 검증과 같은 상한이며, 초과 입력은 저장 전 거절하고 초안·
  화면을 유지한다. 서버·엔진·감시와 연결하지 않는다. 변경 파일은
  `web/board/board.js`, `web/board/board.test.js`,
  `docs/D02-BOARD-PROGRESS.md`, 이 기록이다.
- 검증: Node 보드 **18 passed** (기존 16 + 신규 2), `node --check` 4파일,
  `git diff --check` 통과 (Node `v26.7.0`). 지정 PC에 Python 3.10.8
  32비트를 새로 설치하고 전체 회귀를 실행했다: pytest **177 passed,
  4 subtests passed** (`7.81s`), `python -m execution` 가상 데모 정상,
  Ruff check/format은 기존 `tests/test_realtime_probe.py` 1파일의 기존
  진단만 남고 변경 파일은 통과다. 키움 로그인·주문/조회, 운영 DB, 배포는
  실행하지 않았다.
- 이후 개발용 차단 목록 (근거·완료 기준은 기존 문서 유지):
  D01 실인증 제공자·권한 검증기, Q12 매수 패턴 명세, 장중 FID 10·20 원문과
  수신 순번 (D03 관찰 도구는 `docs/D03-VIRTUAL-STOP-PROGRESS.md` 절차 대기),
  물리 모바일 확인, D03 실제 어댑터·세션, D04~D10, Windows 전체 회귀 재실행.
  실/모의 주문 API·운영 DB·배포는 별도 명시 지시 없이 수행하지 않는다.
- 재개 시 `git status`와 원격 `main`을 먼저 확인하고, 아래 기존 기록의
  완료 조건·차단 경계와 각 단계 MD를 따른다.

## 2026-09-26 D01 설정 적용·복구 경계

- 시작 기준: fetch 후 `HEAD`/`origin/main` 모두
  `c147e69138b7551b8af0cad971812c31aa4636dd`, `main`, 시작 시 clean.
- inbox와 engine ledger가 각각 독립 SQLite임을 확인했다. 두 DB 간 원자성 대신
  inbox `APPLYING` → ledger의 config+stop binding 단일 트랜잭션 → inbox
  `APPLIED`의 재개 프로토콜을 추가했다. command ID/digest, stale version,
  explicit retry, legacy acceptance fail-closed를 검사하며 기존 체결의 rule
  assignment는 교체하지 않는다. `APPLIED`는 로컬 기록 상태이며 monitoring은 계속 false다.
- 인증 제공자/검증기는 현 저장소에 없다. 기본 `ConfigInbox`는 인증 불가 시
  거절한다. 테스트용 fake authenticator만 있으며 실제 Actor claim을 인증 증거로
  가장하지 않는다. legacy accepted rows는 `APPLY_BLOCKED`로 격리한다.
- Windows 사용자 Python 3.10.8 32비트: D01 관련 pytest **27 passed**,
  전체 pytest **177 passed, 4 subtests passed**, 변경 파일 Ruff 검사·포맷,
  가상 데모 및 `git diff --check` 통과. 저장소 전체 Ruff는 기존
  `tests/test_realtime_probe.py`의 lint/format 오류로 실패. basedpyright는 미설치.
- 변경/검증 상세와 D01 완료 전 차단사항은 [D01 진행 기록](D01-SETTINGS-CONTRACT.md)에 있다.
  실인증, 실/모의 키움 주문, 운영 DB, 배포는 하지 않았고 커밋·푸시도 하지 않았다.

## 2026-09-26 재개 체크포인트 — D02 저장 경계

- 시작 `main` `8e4c927`, clean. D03 관찰 도구는 다음 거래일 장중 원문을 기다린다. 출근 전 로그인과 `--start-at` 예약은 `docs/D03-VIRTUAL-STOP-PROGRESS.md`의 최신 기록을 따른다. 실제 시세의 정규화, 거래소 세션과 틱 고유성은 아직 미검증이며 실제 손절 어댑터로 연결하지 않는다.
- 병행 가능한 D02 작업으로 브라우저 초안의 저장 실패 후 메모리 유출과 여러 탭 덮어쓰기 경로를 수정했다. 종목·패턴 변경은 브라우저 저장 성공 뒤 화면 상태로 반영하며, 저장소 원문이 다른 탭에서 바뀌었으면 이번 편집은 거절하고 새로고침을 안내한다.
- 검증: Node 보드 **16 passed**, `node --check web/board/board.js`, `git diff --check` 통과. Windows Python 전체 회귀·실제 모바일 브라우저는 이번 변경에 대해 실행하지 않았다. 변경 파일은 `web/board/board.js`, `web/board/board.test.js`, `docs/D02-BOARD-PROGRESS.md`, 이 기록이다. 키움 로그인·주문/조회, 운영 DB, 배포는 실행하지 않았다.
- 다음 착수: 먼저 `git status`와 원격 `main`을 확인한다. D02는 Q12 매수 패턴 명세, 물리 모바일 확인, 서버 인증·desired/accepted/applied 계약이 남았다. D03은 장중 FID 10·20 원문을 받은 뒤 형식·수신 시각·중복 근거를 검토한다. D04 주문 실패/미체결은 증권사 조회 근거 전에는 실제 실행에 연결하지 않는다. 완료 판단은 각 단계 계획의 종료 조건과 실증 결과로 따로 한다.

지정 Windows PC의 주문 없는 검사 및 향후 키움 읽기 전용 증거 수집 준비는
[키움 로컬 검증 안내](KIWOOM-LOCAL-VERIFICATION-GUIDE.md)에 정리했다.

## 2026-09-26 D03 가상 시세 입력 경계

- 시작 기준: `git fetch origin main` 뒤 `HEAD`/`origin/main` 모두
  `fc6f334d1d01a81d0c29223330562881079ec25b`, `main`, 시작 시 clean.
- `Ledger.process_virtual_stop_quote`가 종목·신선도·단조 수신시각·평가시각을
  확인하고 SQLite에 시세 checkpoint와 발동 latch를 원자적으로 기록한다.
  중복·역순·평가시계 역행·미래/오래된 시세·다른 종목은 checkpoint 및 손절
  발동에 영향을 주지 않는다. checkpoint는 종목별 최신값만 유지하며 schema v1→v2
  마이그레이션을 추가했다. 이미 구현된 청산 의무·dispatcher 복구는 재작성하지 않았다.
- `REGULAR`은 가상 재생 값으로 한정한다. 가상 dispatcher는 실제 주문 전송
  기능이 없고 실제 주문 가능 상태는 `False`; 거래소 시간표/휴장일 근거가
  없으므로 실제 전송은 차단 상태다.
- Windows 사용자 설치 Python 3.10.8 32비트: 관련 pytest **27 passed**,
  전체 pytest **163 passed**, Ruff check/format, `python -m execution` 데모 및
  `git diff --check` 모두 종료 코드 0. 고유 pytest basetemp 사용. `.venv`와
  basedpyright는 없어 잠금 환경/type-check는 미실행.
- 키움 API와 운영 DB, 실제·모의 정정·취소·주문, 배포는 사용하지 않았다.
  상세 검사 명령 및 남은 D03 조건은 [D03 기록](D03-VIRTUAL-STOP-PROGRESS.md)에 있다.

- 기록일: 2026-09-24
- 확인한 GitHub `main`: `c38010d` (`Handle cross-symbol config command identity conflicts`)
- 이 기록의 목적: 대화가 중단되어도 현재 확인된 상태, 다음 작업 및 완료 판단 기준을 복원한다.
- 이 파일을 작성한 작업 공간에는 후속 **미커밋 변경**이 있을 수 있다. 재개 시 `git status`를 먼저 확인한다.
- 우선 기준: `AGENTS.md` → `docs/CherryPulse-KR-01-Development-Direction.md` → `docs/CherryPulse-KR-01-Rebuild-Plan.md` → `docs/REBUILD-02-CONTRACTS.md` → `docs/REBUILD-02-TEST-MATRIX.md` → `docs/REBUILD-02-OPEN-QUESTIONS.md`. 작업 순서는 `docs/NEXT-DEVELOPMENT-PLAN.md`를 따른다.

## 이번 대화에서 확인한 내용

1. GitHub `main`의 `c38010d`에는 D01 명령 ID를 같은 계좌·환경의 다른 종목에 재사용했을 때 명시적인 `CONFLICT_CONFIG_COMMAND_IDENTITY`로 처리하는 수정이 있다. 실제 원격 파일 내용을 확인했다.
2. 이 수정의 로컬 Linux Python 3.12 분리 검사에서 D01 관련 pytest **9 passed**, Ruff 및 `git diff --check`가 통과했다. Windows 3.10 32비트 전체 검사 또는 키움 검증 결과는 아니다.
3. 원격 커밋 `c38010d`는 이 작업 공간의 원래 로컬 커밋 `b478dc3`과 해시가 다르지만 해당 수정 파일의 내용은 일치한다. 로컬 작업은 원격 `main`의 트리를 기준으로 다시 시작해야 한다.
4. 현재 실제 주문 API 호출, 운영 DB 변경, 배포를 수행하지 않았다. D01~D10 전체 완료를 주장하지 않는다.

## 현재 상태와 다음 순서

| 단계 | 확인된 상태 | 다음에 필요한 작업 |
|---|---|---|
| D01 | 원하는 설정 수신·보관 및 로컬 가상 손절 규칙 저장은 존재한다. 인증과 적용 원장의 원자적 연결은 미완료 | 인증 경계와 desired/accepted/applied 상태 연결. `ACCEPTED`를 감시 활성화로 표시하지 않기 |
| D03 | 가상 손절 발동·보호 후보·요청별 의무와 조회·실패 후 재주문 차단 일부 구현 | 자동 시세 감시, 검증된 세션, 실제 조회·알림 및 남은 실행정책 검증. D03 완료로 간주하지 않기 |
| D02·D04~D10 | 비활성 보드와 종목 등록·편집·검색·보관, 손절 버전, JSON/CSV 교환 및 전체 보드 백업·복원 구현. 각 계획 완료 기준에는 미도달 | Q12 매수 패턴 명세, 실제 적용 흐름 및 단계별 계획 완료 기준 필요 |

D02의 비활성 보드 골격은 `web/board/`에 추가했다. 브라우저 안에서만
저장되는 종목·손절 패턴 초안이다. 최초 기록 이후 Chrome emulation 검증은
아래 2026-09-25 후속 내용에 갱신했다.
`docs/D02-BOARD-PROGRESS.md`를 확인하고 엔진 적용 상태와 혼동하지 않는다.

`New.stop_latch_version` 연결과 요청별 청산 의무 기록·조회가 현재 `main`에 존재한다. 최신 상세 범위와 남은 한계는 `docs/D03-VIRTUAL-STOP-PROGRESS.md`를 따른다. `UNKNOWN`은 조회 근거 없이 실패로 바꾸거나 재전송하지 않는다.

추가 단계에서는 요청별 `StopSellObligation`을 주문 요청과 한 트랜잭션에
기록하고 재시작·중복 요청·매도 부분체결 뒤에도 원래 연결이 유지되는지
검증했다. Linux 임시 fixture의 관련 pytest **10 passed**, Ruff 통과.
이 단계에서는 의무의 동적 잔량/완료 상태 조회, 취소·거절·`UNKNOWN`
대조, 자동 시세 감시와 검증된 거래 세션을 아직 완료하지 않았다.

후속 조회 단계에서는 원장 사실에서 의무별 부분체결·완료·미확정·거절
상태를 읽는 API를 추가했다. 이 상태 조회는 재주문 권한을 주지 않는다.
자동 시세 감시, 키움 조회 증거와 실제 세션, 거절·취소 이후 외부 조회·알림
연결은 여전히 남아 있다.

사용자 선택 1번을 반영해 가상 손절 매도 실패·거절 시 자동 재주문을
차단하는 기존 동작을 재시작까지 확인하고, 의무 조회에 다음 확인 행동
(`QUERY_BROKER`/`REVIEW_AND_ALERT`/`NONE`)을 추가했다. 관련 가상
pytest **11 passed**, Ruff와 공백 검사 통과. 상세 범위는
`docs/D03-VIRTUAL-STOP-PROGRESS.md`를 참고한다. 증권사 상태 조회,
알림 발송 및 미체결 판단 시간은 연결되지 않았다. 기존 보유분 편입 정책은
답변을 받지 않았으므로 원가·수량·규칙 인계가 확인될 때까지 차단한다.
이어서 기록된 거절·전송 실패 사유를 미완료 의무와 함께 읽도록 보완했다.
추가 가상 검사에서 관련 pytest **12 passed**, Ruff·공백 검사 통과.

## 2026-09-25 후속 진행

- 시작 기준: `main`의 `d62f8a2` (`origin/main`과 일치), 작업 시작 시 미커밋 변경 없음.
- D02에서 손절 기준·시장가/지정가 선택을 버전 초안에 저장하고, 패턴 비활성화와 재활성화를 제공한다. 이전 버전 연결은 유지하며 비활성 버전은 새 연결에 사용할 수 없다. 지정가 가격·호가·세션·미체결 처리는 미정이다. 상세 동작은 [D02 진행 기록](D02-BOARD-PROGRESS.md)에 있다.
- `node --test web/board/board.test.js` 8 passed, 세 JS 파일의 `node --check`, `git diff --check` 통과. 별도 Windows 회귀로 Python 3.10.8 32비트 전체 pytest 159 passed, Ruff 검사·포맷, 가상 데모, `pip check` 통과. 격리 `.venv`가 없어 사용자 설치 Python으로 검사했다. 아래 9/25 추가 검증에서 headless Chrome 모바일/데스크톱 viewport와 상호작용도 확인했다.
- 이 버전 기록은 브라우저 로컬 초안의 UX이며 D01 서버 계약·인증이나 엔진의 불변 설정 적용을 대신하지 않는다. D02의 매수 패턴 입력 폼은 Q12의 사용자 명세가 없어 미착수이며, 물리 모바일 기기 확인은 남아 있다. D01 desired/accepted/applied 적용은 인증·동기화 경계가 필요하다. D03 자동 시세·검증 세션, D04~D10 및 키움 실증은 별도 미완료다.

## 2026-09-25 REBUILD-01/Q13 정적 확인

- 현행 `execution/`, `contracts/`, `adapters/` Python 23개를 AST로 검사해
  `back/` 및 구 실행 모듈 import와 프로세스 생성 호출이 0건임을 확인했다.
  단순 문자열 검색의 한 일치는 `execution/query_evidence.py` docstring이다.
- 검증 스크립트 범위를 소스에서 구분했다. COM-only 검사는 아래 후속 기록에서
  실행했으며, 연결 상태 관측과 사용자가 시작하는 읽기 전용 TR 조회는 실행하지
  않았다.
- Windows 읽기 전용 키워드 조사에서 관련 예약 작업·프로세스·서비스 이름은
  각각 0건이었다. 실행 인수·서비스 구성은 출력하지 않았다.
- 범위와 조사 한계는 [보관·정적 조사 기록](REBUILD-01-ARCHIVE.md) 및
  [미확인 사항 Q13](REBUILD-02-OPEN-QUESTIONS.md)에 기록했다. 서비스·모든
  예약 작업·외부 래퍼·다른 PC·실제 계좌/보유 인계는 미확인이므로 Q13은 계속
  미해결이다.

## 2026-09-25 브라우저 재확인

- PATH 조회에서 빠졌던 설치 Chrome을 직접 경로로 찾아 실행했다. 390×844 모바일
  emulation에서 단일 열·가로 넘침 없음, 1365px 데스크톱 emulation에서 두 열을
  확인했다.
- 브라우저 안에서 종목 등록, 손절 패턴 생성 및 연결, 다음 버전 생성(LIMIT),
  이전 버전 비활성화 후 기존 연결 유지와 새 연결 차단을 재현했다. Q12 대기
  매수 패턴 패널도 두 viewport에서 표시됨을 확인했다. 상세는 [D02 진행 기록](D02-BOARD-PROGRESS.md)에 있다.
- 물리 휴대폰 화면·터치 테스트는 하지 않았다. 이 결과로 서버 저장, 로그인,
  엔진 설정 적용이 검증된 것은 아니다.
- 주문 없는 환경 검사로 Python 3.10.8 32-bit/PyQt5 5.15.11/Qt 5.15.2에서
  `verify_kiwoom_com.py`를 실행했다. COM 생성·해제 성공. 로그인·이벤트 루프·계좌
  조회·TR·주문은 호출하지 않았다. Q10의 로컬 호환성 증거만 추가한 결과다.

## 2026-09-25 관심종목 일괄 가져오기

- 작업 시작 기준은 `main`의 `9bb5f5c`, 시작 당시 작업 트리는 깨끗했다.
- 보드에 JSON/CSV 종목 초안 가져오기를 추가했다. UTF-8 canonical format,
  행 단위 검증, 기존/파일 내 중복 차단, 전체 성공 시에만 추가, 5 MiB 제한을
  적용한다. 가져온 데이터는 브라우저 초안이고 패턴/엔진 적용/감시와 연결하지 않는다.
- Node 검사 **8 passed**. Chrome 모바일 emulation에서 CSV 가상 파일 2행을
  가져와 저장·카드 렌더링까지 확인했다. Chrome headless에서 관심종목 JSON/CSV
  다운로드와 파일 내용을 확인했다. 최종 양 viewport에서 가로 넘침 없이 레이아웃을
  재확인했다. 구현·형식은 [D02 기록](D02-BOARD-PROGRESS.md).

## 2026-09-25 CSV 관심종목 내보내기

- 시작 기준은 `main`의 `f4822a2`, 작업 시작 시 트리는 깨끗했다.
- JSON 내보내기에 CSV 내보내기를 추가해 둘 다 기존 일괄 가져오기와 왕복 호환되게
  했다. CSV quoting, UTF-8 BOM, 보관/패턴 링크 제외를 검증했다.
- Node 보드 테스트 **8 passed**, 구문 검사와 `git diff --check` 통과.
  Chrome 모바일 emulation에서 실제 CSV 다운로드 완료와 파일 내용을 확인했다.
- 다운로드는 활성 종목 데이터만 포함하며 전체 보드 백업이나 엔진 설정 내보내기가
  아니다. 상세 구현·범위는 [D02 진행 기록](D02-BOARD-PROGRESS.md)에 있다.

## 2026-09-25 관심종목 검색

- 작업 시작 기준은 `main`의 `045a63d`, 작업 시작 시 트리는 깨끗했다.
- 현재 목록 범위 안에서 종목코드·종목명·링크·메모를 검색하며 관심/보관 필터와
  조합해 사용할 수 있다. 검색은 초안 데이터를 변경하지 않는다.
- Node 테스트 **9 passed**. Chrome 모바일·데스크톱 emulation에서 가로 넘침 없는
  레이아웃, 검색 결과 및 보관 탭 필터 조합을 확인했다.

## D02 전체 보드 백업·복원 — 2026-09-25

- 시작 기준: `main`/`origin/main`의 `9ef1470`; 작업 시작 시 브랜치 `main`, 작업 트리
  clean, rebase 진행 상태 없음.
- 전체 백업은 `schemaVersion: 1`로 종목·보관 상태·패턴 전 버전·활성 상태·연결을
  포함한다. 복원 파일 전체 검증 후 대체 확인을 받고, localStorage 저장 성공 전에는
  현재 in-memory 화면 상태를 바꾸지 않는다. 기존 localStorage 포맷은 별도 마이그레이션
  없이 계속 읽는다.
- Node 전체 테스트 **14 passed**. Chrome 모바일에서 백업 다운로드, 확인 전 유지,
  취소, 복원 및 reload를 확인했다. 데스크톱 emulation에서 복원 확인/취소도 확인했다.
- Windows Python 3.10.8 32비트 사용자 설치 환경에서 pytest **159 passed**, Ruff 검사·
  포맷, 가상 데모 및 `pip check` 통과. 격리 `.venv`와 basedpyright는 사용할 수 없어
  고정 환경/type-check는 미실행이다. 주문 API·운영 DB·배포는 실행하지 않았다.

## D03 가상 손절 재시작 경계 재검토 — 2026-09-25

- 시작 기준: fetch 후 `main`/`origin/main` 모두 `1ddab2074a54ca51903d548be618dd9ac737cb71`,
  브랜치 `main`, 작업 트리 clean. 이전 수정은 이미 동일 종목의 격리 의무를
  `SENDING` 전에 차단하고 있었다. 그 로직은 재구현하지 않았다.
- `tests/test_virtual_stop_binding.py`에 부분 매도·`UNKNOWN` 취소·의무 기록 손실
  후 지연 매수/후속 의도 시나리오의 dispatcher 재시작 검사를 확장했다.
  `BLOCKED_EVIDENCE`에서는 후속 요청을 `SENDING`으로 바꾸지 않고 가상 호출도 0이다.
- 변경 파일은 이 테스트 파일과 [D03 진행 기록](D03-VIRTUAL-STOP-PROGRESS.md)뿐이다.
- 전체 Windows 회귀 **161 passed in 11.68s**. Ruff check, Ruff format check,
  `python -m execution`, `pip check`, `git diff --check` 통과. 첫 동시 실행은
  120초 도구 제한에 걸렸으나 단독 fresh-basetemp 재실행에서 통과했다(원인은 재현되지 않음).
  User-installed Python 3.10.8 32-bit이며 격리 `.venv`/basedpyright는 미사용이다.
- 조사 중 신규 production 결함은 재현되지 않았다. 첫 새 assertion은 orphan 의무가
  있는 상태의 후속 의무를 `PENDING`으로 잘못 예상했으나 실제 `BLOCKED_EVIDENCE`가
  확인되어 안전한 기대값으로 수정했다.
- 키움 API·조회·주문, 운영 DB와 배포는 사용하지 않았다. 자동 시세·검증된 세션·
  실제 조회/알림은 여전히 D03 완료를 막는다.

## 완료 전 필요한 외부 결정·검증

- **Q12/D02/D05:** 매수 패턴 조건, 주문 수량/금액, 주문 방식, 거래 시간,
  취소·미체결, 재진입 규칙. 정해지지 않은 값을 코드 기본값으로 만들지 않는다.
- **D01/D08:** 인증 제공자와 주체·계좌 권한의 신뢰 경계, 클라우드 저장소,
  desired/accepted/applied 전이와 재시작 복구 정책. 비밀값이나 토큰을 MD에
  기록하지 않는다.
- **D02/D09:** D02 로컬 화면은 Chrome headless responsive emulation을 확인했다.
  물리 휴대폰 확인과 실제 운영 보드(D08 연동)는 미완료다.
- **D03/D06:** 자동 시세 원천과 실제 세션 검증, Q01~Q11의 읽기 전용 키움
  자료·필드 의미 및 계좌 보유 인계 근거. 확인된 자료 없이 실제 주문 매핑을
  만들지 않는다.
- **D07/D10:** 지정 PC·계좌의 운영 인계와, 별도 명시적 지시가 필요한 실제/모의
  주문 API·운영 DB·배포. 이번 요청만으로 해당 실행을 승인한 것으로 보지 않는다.

## 완료 조건과 차단 경계

- D01~D10의 세부 완료 기준은 `docs/NEXT-DEVELOPMENT-PLAN.md`와 `docs/DEVELOPMENT-GOAL.md`를 따른다. 문서 검사, Linux 가상 검사, Windows 검사, 키움 실증을 구별한다.
- 실제/모의 키움 주문 API, 운영 DB 변경, 배포는 별도 명시적 지시 및 지정 환경 확인 전에는 수행하지 않는다. 인증된 키움 조회 자료가 없는 상태에서 주문 필드와 세션 동작을 추정해 활성화하지 않는다.
- 거절·실패 후 자동 재주문 금지는 확정했다. 미체결 판단 시간, 기존 보유의 원가/규칙 인계, 키움 조회·체결의 식별자 의미는 근거와 사용자 결정이 없으면 차단 상태로 둔다. 그동안 가상 검증과 비활성 화면은 진행할 수 있다.
- 이 문서는 진행 상황의 기록이며 자동 백그라운드 실행이나 커밋·푸시 허가를 뜻하지 않는다. 작업 재개 시 `git status`, 원격 `main`, 관련 문서와 실제 테스트 결과를 다시 확인한다.

## 새 대화에서 사용할 요청

> CherryPulse-KR-01의 `AGENTS.md`, `docs/WORK-CONTINUATION-STATUS.md`, `docs/DEVELOPMENT-GOAL.md`, `docs/NEXT-DEVELOPMENT-PLAN.md`를 읽고 원격 `main` 및 로컬 변경을 확인한 뒤 D03의 가상 손절 의무와 매도 요청 연결부터 완료 조건대로 계속 진행해 줘. 매 단계에 실제 테스트 결과와 미검증 범위를 기록하고 다음 안전한 작업을 이어서 진행해 줘. 실제/모의 주문 API, 운영 DB 변경, 배포는 별도 명시적 지시 없이 수행하지 마.
