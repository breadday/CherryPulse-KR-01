1.  이번 단계 목표

1) 실전 엔진 MVP

- 전략 신호 생성
- 주문 요청
- 주문 상태 관리
- 체결 반영
- 포지션/잔고 갱신
- 리스크 제한
- 로그 저장


2) 프로젝트 구조 확정

CherryPulse-KR-01/ 아래를 이렇게 가져가면 됩니다.

CherryPulse-KR-01/
│
├─ backtest/
│  ├─ runner.py
│  ├─ metrics.py
│  ├─ adapters.py
│  └─ csv_feed.py
├─ main.py
├─ config.py
├─ engine.py
├─ broker/
│  ├─ __init__.py
│  ├─ base.py
│  └─ kiwoom_stub.py
├─ data/
│  ├─ csv_loader.py
│  └─ sample/
│     └─ 005930_1m.csv
├─ strategy/
│  ├─ __init__.py
│  └─ momentum_intraday.py
│
├─ core/
│  ├─ __init__.py
│  ├─ models.py
│  ├─ portfolio.py
│  ├─ risk_manager.py
│  ├─ order_manager.py
│  └─ event_bus.py
│
├─ data/
│  ├─ __init__.py
│  └─ market_stream.py
│
├─ utils/
│  ├─ __init__.py
│  └─ logger.py
│
└─ logs/
   run_backtest_csv.py

3) 핵심 설계

이번 단계에서 중요한 건 전략과 주문 실행을 분리하는 겁니다 👉

흐름은 이거예요.

실시간 데이터 수신
→ 전략 판단
→ 리스크 체크
→ 주문 생성
→ 브로커 전송
→ 체결 반영
→ 포트폴리오 갱신
→ 로그 기록


5. 다음 단계 우선순위

이제 진짜 중요한 건 여기입니다 🪙

A. Kiwoom OpenAPI 실연동

스텁 브로커를 실제 API 브로커로 교체

로그인
계좌조회
실시간 시세 등록
주문 전송
주문/체결 이벤트 수신
B. 이벤트 기반 구조 전환

지금은 on_tick()에 직접 처리했지만
실전은 아래 이벤트가 따로 와야 합니다.

시세 이벤트
주문접수 이벤트
체결 이벤트
잔고변경 이벤트
장상태 이벤트
C. 미체결/정정/취소

실전에서는 필수입니다.

지정가 주문 미체결 시 정정
일정 시간 후 취소
부분체결 시 잔량 관리
D. 리스크 강화
종목당 비중 제한
장중 신규진입 제한 시간
일일 손실 도달 시 전체 중지
종목별 쿨다운 시간

6. CherryPulse-KR-01 다음 스텝 제안

가장 좋은 순서는 이겁니다 👉

Step 1

지금 코드로 엔진 뼈대 로컬 실행

Step 2

KiwoomStubBroker를
KiwoomBroker로 교체

Step 3

실시간 체결강도/호가/틱 데이터를 받아
전략 입력으로 연결

Step 4

모의투자 계좌로 1종목 자동주문 검증

Step 5

장애복구 + 미체결관리 + 로그리포트 추가


7. 현실적으로 꼭 짚고 갈 점

“완전체”라고 해도 바로 실전에 넣으면 위험합니다.

특히 아래는 아직 없습니다.

실계좌 키움 OpenAPI 연결 코드
QEventLoop 기반 이벤트 처리
재로그인
API 끊김 복구
미체결 정정/취소
TR 요청 제한 대응
체결강도/호가 기반 실시간 진입 로직

이건 제가 지어내면 안 됩니다.
실제 연동부는 키움 이벤트 구조에 맞게 정확히 붙여야 해요 👍


가장 현실적인 점검 순서

1단계: 로그인
2단계: 예수금/잔고 조회
3단계: 실시간 틱 수신
4단계: 모의계좌 1주 주문
5단계: 체결 이벤트 확인
6단계: 포트폴리오 값 검산


engine.py 수정
strategy도 같이 봐줘
통복붙으로 줘


### 앞으로 운영 기준을 이렇게 고정하면 된다 ###

개발/디버깅: python main.py
실전(모의투자 계좌 포함): python main_live.py


python main_live_param.py --list-cases
python main_live_param.py --mode dry --case case3
python main_live_param.py --mode dry --case case1 --test-name my_case1_test
python main_live_param.py --mode live
python main_live_param.py --mode live --symbols 005930,000660,035720

핵심 개선점은 이거야 ✌️🍵

--mode dry | live 로 테스트/실전 분리
--case case1 ~ case5 로 케이스 선택
--test-name 으로 CSV 파일명 관리
--symbols 로 구독 종목 변경
--list-cases 로 케이스 목록 확인

즉 이제는

테스트할 때: 
python main_live_param.py --mode dry --case case1
