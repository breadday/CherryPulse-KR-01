from collections import deque


class MomentumIntradayStrategy:
    def __init__(self):
        self.price_history = {}
        self.volume_history = {}

    def on_tick(self, tick):
        symbol = tick.symbol
        price = tick.price
        volume = tick.volume

        if symbol not in self.price_history:
            self.price_history[symbol] = deque(maxlen=20)
            self.volume_history[symbol] = deque(maxlen=20)

        prices = self.price_history[symbol]
        volumes = self.volume_history[symbol]

        prices.append(price)
        volumes.append(volume)

        if len(prices) < 10:
            return None

        # -------------------------
        # 1. 거래량 필터
        # -------------------------
        avg_volume = sum(volumes) / len(volumes)
        if volume < avg_volume * 1.5:
            return None

        # -------------------------
        # 2. 변동성 필터
        # -------------------------
        min_price = min(prices)
        max_price = max(prices)
        volatility = (max_price - min_price) / min_price

        if volatility < 0.01:  # 1% 이하 움직임 → 스킵
            return None

        # -------------------------
        # 3. 추세 필터
        # -------------------------
        ma5 = sum(list(prices)[-5:]) / 5
        ma10 = sum(prices) / len(prices)

        if price < ma5 or ma5 < ma10:
            return None

        # -------------------------
        # 4. 돌파 매수
        # -------------------------
        if price >= max_price:
            return {
                "action": "BUY",
                "symbol": symbol,
                "reason": "거래량+변동성+추세 돌파"
            }

        return None