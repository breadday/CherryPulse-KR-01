import time
from datetime import datetime

import config
from core.models import Order, TickData, OrderStatus, Signal, Side, OrderType
from core.order_manager import OrderManager
from core.portfolio import Portfolio
from core.risk_manager import RiskManager
from utils.news_theme_score import build_external_scores


class TradingEngine:
    def __init__(self, broker, strategy, logger, telegram=None, initial_cash=5_000_000):
        self.broker = broker
        self.strategy = strategy
        self.logger = logger
        self.telegram = telegram

        self.portfolio = Portfolio(initial_cash=initial_cash)
        self.risk_manager = RiskManager()
        self.order_manager = OrderManager()

        self.is_running = False

        # -------------------------
        # 주문 방어 설정
        # -------------------------
        self.last_order_time = {}
        self.order_cooldown_sec = 10
        self.daily_order_count = 0
        self.max_daily_orders = 20
        self.current_trading_date = datetime.now().date()

        self.min_tick_volume = 1
        self.max_symbol_position = 1

        self.broker.set_real_tick_callback(self.on_real_tick)
        self.broker.set_fill_callback(self.on_fill)
        self.broker.set_msg_callback(self.on_broker_msg)

        self.sell_in_progress = set()
        self.last_price_map = {}
        self.reentry_block_until = {}
        self.last_exit_reason = {}
        self.partial_exit_done = set()
        self.breakeven_active = set()
        self.trailing_high_price = {}
        self.cancel_in_progress = set()
        self.pending_resell = {}
        self.resell_retry_count = {}
        self.abandon_resell_symbols = set()
        self.last_cancel_request_time = {}
        self.consecutive_loss_count = 0
        self.error_count = 0
        self.engine_protected = False

    # -------------------------
    # 안전 변환 유틸
    # -------------------------
    def _safe_int(self, value, default=0):
        try:
            if value in ("", None):
                return default
            if isinstance(value, str):
                value = value.replace(",", "").strip()
            return int(float(value))
        except Exception:
            return default

    def _safe_float(self, value, default=0.0):
        try:
            if value in ("", None):
                return default
            if isinstance(value, str):
                value = value.replace(",", "").strip()
            return float(value)
        except Exception:
            return default

    def _extract_score_from_reason(self, reason: str):
        """
        reason 예:
        momentum_entry:ok:score=52.3:news=8.0:theme=6.0:leader=10.0
        """
        try:
            if not reason:
                return None

            for token in str(reason).split(":"):
                if token.startswith("score="):
                    return float(token.split("=", 1)[1])
        except Exception:
            return None

        return None

    def _build_external_scores(self, raw_tick: dict):
        """
        Step 21 1차 버전:
        - 실시간 뉴스 크롤링 연결 전까지는 raw_tick 안에 값이 있으면 사용
        - 없으면 symbol 기반 간단 테마/주도 점수만 부여
        """
        symbol = str(raw_tick.get("symbol", ""))

        # 1) raw_tick에 이미 점수가 들어오면 우선 사용
        news_score = self._safe_float(raw_tick.get("news_score", 0.0), 0.0)
        theme_score = self._safe_float(raw_tick.get("theme_score", 0.0), 0.0)
        leader_score = self._safe_float(raw_tick.get("leader_score", 0.0), 0.0)

        if news_score != 0.0 or theme_score != 0.0 or leader_score != 0.0:
            return {
                "news_score": news_score,
                "theme_score": theme_score,
                "leader_score": leader_score,
                "total_external_score": round(news_score + theme_score + leader_score, 2),
            }

        # 2) 임시 수동 매핑
        theme_map = {
            "005930": ["반도체", "AI", "HBM"],
            "000660": ["반도체", "AI", "HBM"],
        }

        leader_map = {
            "005930": ["반도체 대장", "시총상위"],
            "000660": ["HBM 대장", "강세"],
        }

        market_rank_map = {
            "005930": 5,
            "000660": 3,
        }

        scores = build_external_scores(
            news_items=[],
            theme_texts=theme_map.get(symbol, []),
            leader_texts=leader_map.get(symbol, []),
            market_rank=market_rank_map.get(symbol),
            is_upper_limit=False,
            is_new_high=False,
        )

        return scores

    # -------------------------
    # 장 시간 체크
    # -------------------------
    def is_market_open(self):
        now = datetime.now().time()
        market_open = datetime.strptime("09:00", "%H:%M").time()
        market_close = datetime.strptime("15:30", "%H:%M").time()
        return market_open <= now <= market_close

    # -------------------------
    # 일자 변경 시 카운터 리셋
    # -------------------------
    def reset_daily_counters_if_needed(self):
        today = datetime.now().date()
        if today != self.current_trading_date:
            self.current_trading_date = today
            self.daily_order_count = 0
            self.last_order_time = {}
            self.logger.info("일일 주문 카운터 초기화")

    # -------------------------
    # 시작 / 종료
    # -------------------------
    def start(self):
        self.broker.connect()
        self.is_running = True
        self.logger.info("브로커 연결 완료")

    def stop(self):
        if not self.is_running:
            self.logger.info("이미 종료 상태")
            try:
                self.broker.shutdown()
            except Exception as e:
                self.logger.warning(f"브로커 종료 실패 | {e}")
            return

        self.logger.info("엔진 종료 시작")

        try:
            self.broker.shutdown()
        except Exception as e:
            self.logger.warning(f"브로커 종료 실패 | {e}")

        self.is_running = False
        self.logger.info("엔진 종료 완료")

    # -------------------------
    # 계좌 동기화
    # -------------------------
    def sync_account(self, password: str = ""):
        try:
            deposit = self.broker.get_deposit(password=password)
            time.sleep(1.0)
            positions = self.broker.get_positions(password=password)

            self.logger.info(f"예수금 동기화 완료 | deposit={deposit}")
            self.logger.info(f"보유종목 동기화 완료 | count={len(positions)}")

            if hasattr(self, "portfolio"):
                self.portfolio.cash = deposit

            if hasattr(self, "portfolio"):
                for item in positions:
                    symbol = item["symbol"]
                    qty = int(item["qty"])
                    avg_price = float(item["avg_price"])

                    pos = self.portfolio.get_position(symbol)
                    pos.qty = qty
                    pos.avg_price = avg_price
                    pos.partial_taken = False
                    pos.highest_return_pct = 0.0

                    self.logger.info(
                        f"포지션 반영 | symbol={symbol} qty={qty} avg_price={avg_price}"
                    )

            return {
                "deposit": deposit,
                "positions": positions,
            }

        except Exception as e:
            self.logger.exception(f"계좌 동기화 실패 | {e}")
            return {
                "deposit": 0,
                "positions": [],
            }

    def sync_pending_orders(self, password: str = ""):
        try:
            pending_orders = self.broker.get_pending_orders(password=password)
            self.logger.info(f"미체결 주문 동기화 시작 | count={len(pending_orders)}")

            restored = 0

            for item in pending_orders:
                symbol = item["symbol"]
                order_no = item["order_no"]
                side = item["side"]
                order_qty = int(item["order_qty"])
                unfilled_qty = int(item["unfilled_qty"])
                filled_qty = int(item["filled_qty"])
                order_price = float(item["order_price"])
                order_status = str(item["order_status"])

                if unfilled_qty <= 0:
                    continue

                local_id = f"RESTORE_{order_no}"

                if self.order_manager.get_order(local_id) is not None:
                    continue

                order_type = OrderType.LIMIT if order_price > 0 else OrderType.MARKET
                status = OrderStatus.PARTIAL if filled_qty > 0 else OrderStatus.SUBMITTED

                restored_order = Order(
                    order_id=local_id,
                    symbol=symbol,
                    side=side,
                    qty=order_qty,
                    price=order_price,
                    order_type=order_type,
                    status=status,
                    filled_qty=filled_qty,
                    avg_fill_price=order_price if filled_qty > 0 else 0.0,
                    reason=f"restored_pending:{order_status}",
                )

                self.order_manager.register(restored_order)
                self.order_manager.broker_to_local_id[order_no] = local_id

                restored += 1

                self.logger.info(
                    f"미체결 주문 복원 | symbol={symbol} "
                    f"broker_order_no={order_no} local_id={local_id} "
                    f"side={side} qty={order_qty} filled={filled_qty} "
                    f"remain={unfilled_qty} price={order_price} status={status}"
                )

            self.logger.info(f"미체결 주문 동기화 완료 | restored={restored}")
            return pending_orders

        except Exception as e:
            self.logger.exception(f"미체결 주문 동기화 실패 | {e}")
            return []

    # -------------------------
    # 주기적 미체결 관리
    # -------------------------
    def manage_pending_orders(self):
        try:
            if not self.is_running:
                return

            symbols = set()

            for order in self.order_manager.orders.values():
                if getattr(order, "status", None) in (OrderStatus.SUBMITTED, OrderStatus.PARTIAL):
                    if getattr(order, "symbol", None):
                        symbols.add(order.symbol)

            symbols.update(self.pending_resell.keys())

            for symbol in list(symbols):
                self._check_stale_sell_order(symbol)
                self._retry_sell_after_cancel(symbol)

        except Exception as e:
            self.logger.exception(f"미체결 주문 관리 실패 | {e}")

    # -------------------------
    # 실시간 틱 수신
    # -------------------------
    def on_real_tick(self, raw_tick: dict):
        if self.engine_protected:
            return

        try:
            symbol = str(raw_tick["symbol"])
            price = self._safe_int(raw_tick.get("price", 0), 0)
            volume = self._safe_int(raw_tick.get("trade_volume", raw_tick.get("volume", 0)), 0)

            price_change_pct = self._safe_float(
                raw_tick.get("price_change_pct", raw_tick.get("change_rate", 0.0)),
                0.0,
            )
            trade_strength = self._safe_float(raw_tick.get("trade_strength", 0.0), 0.0)
            volume_ratio = self._safe_float(raw_tick.get("volume_ratio", 0.0), 0.0)

            external_scores = self._build_external_scores(raw_tick)

            self.logger.info(
                f"[TICK] {symbol} price={price} vol={volume} "
                f"chg={price_change_pct} strength={trade_strength} vr={volume_ratio} "
                f"news={external_scores['news_score']} "
                f"theme={external_scores['theme_score']} "
                f"leader={external_scores['leader_score']}"
            )

            if price <= 0:
                return

            self.last_price_map[symbol] = price

            self._check_auto_exit(symbol, price)
            self._check_stale_sell_order(symbol)
            self._retry_sell_after_cancel(symbol)

            tick = TickData(
                symbol=symbol,
                price=price,
                volume=volume,
                ts=datetime.now(),
                price_change_pct=price_change_pct,
                trade_strength=trade_strength,
                volume_ratio=volume_ratio,
                news_score=external_scores["news_score"],
                theme_score=external_scores["theme_score"],
                leader_score=external_scores["leader_score"],
            )
            self.on_tick(tick)

        except Exception as e:
            self.error_count += 1
            self.logger.exception(f"실시간 틱 처리 실패 | tick={raw_tick} err={e}")
            self._check_engine_protection()

    # -------------------------
    # 자동 매도 검사
    # -------------------------
    def _check_auto_exit(self, symbol: str, price: int):
        try:
            pos = self.portfolio.get_position(symbol)
            qty = int(getattr(pos, "qty", 0))
            avg_price = float(getattr(pos, "avg_price", 0))

            if qty <= 0 or avg_price <= 0:
                return

            if symbol in self.abandon_resell_symbols:
                return

            if symbol in self.pending_resell:
                return

            if symbol in self.cancel_in_progress:
                return

            if symbol in self.sell_in_progress:
                return

            if self.order_manager.exists_open_order(symbol):
                return

            pnl_pct = (price - avg_price) / avg_price

            if (
                symbol not in self.partial_exit_done
                and pnl_pct >= config.PARTIAL_TAKE_PROFIT_PCT
            ):
                sell_qty = max(int(qty * config.PARTIAL_TAKE_RATIO), 1)

                self.logger.info(
                    f"부분익절 발생 | symbol={symbol} qty={sell_qty} pnl={pnl_pct:.2%}"
                )

                self.partial_exit_done.add(symbol)

                if config.BREAKEVEN_ENABLED:
                    self.breakeven_active.add(symbol)

                if config.TRAILING_STOP_ENABLED:
                    self.trailing_high_price[symbol] = price

                self._submit_auto_sell(symbol, sell_qty, "부분익절")
                return

            if symbol in self.partial_exit_done and config.TRAILING_STOP_ENABLED:
                prev_high = self.trailing_high_price.get(symbol, 0)
                if price > prev_high:
                    self.trailing_high_price[symbol] = price

            if symbol in self.breakeven_active:
                if price <= avg_price:
                    self.logger.info(
                        f"본절 청산 | symbol={symbol} price={price} avg_price={avg_price}"
                    )
                    self._submit_auto_sell(symbol, qty, "본절청산")
                    return

            if symbol in self.partial_exit_done and config.TRAILING_STOP_ENABLED:
                high_price = self.trailing_high_price.get(symbol, 0)
                if high_price > 0:
                    trailing_stop_price = high_price * (1 - config.TRAILING_STOP_PCT)

                    if price <= trailing_stop_price:
                        self.logger.info(
                            f"트레일링 스탑 청산 | symbol={symbol} price={price} "
                            f"high={high_price} stop={trailing_stop_price:.2f}"
                        )
                        self._submit_auto_sell(symbol, qty, f"트레일링청산 high={high_price}")
                        return

            exit_reason = None

            if pnl_pct >= config.TAKE_PROFIT_PCT:
                exit_reason = f"익절 {pnl_pct:.2%}"
            elif pnl_pct <= config.STOP_LOSS_PCT:
                exit_reason = f"손절 {pnl_pct:.2%}"

            if exit_reason is not None:
                self.logger.info(
                    f"자동매도 조건 충족 | symbol={symbol} price={price} "
                    f"avg_price={avg_price} qty={qty} pnl_pct={pnl_pct:.2%} reason={exit_reason}"
                )
                self._submit_auto_sell(symbol=symbol, qty=qty, reason=exit_reason)

        except Exception as e:
            self.logger.exception(f"자동매도 검사 실패 | symbol={symbol} price={price} err={e}")

    # -------------------------
    # 자동 매도 주문
    # -------------------------
    def _submit_auto_sell(self, symbol: str, qty: int, reason: str):
        try:
            if qty <= 0:
                return

            self.sell_in_progress.add(symbol)

            signal = Signal(
                symbol=symbol,
                side=Side.SELL,
                qty=qty,
                price=0,
                order_type=OrderType.MARKET,
                reason=reason,
            )

            order = self.broker.place_order(signal)
            self.order_manager.register(order)

            if order.status == OrderStatus.SUBMITTED:
                self.last_order_time[symbol] = time.time()
                self.daily_order_count += 1

                if "손절" in reason:
                    self.consecutive_loss_count += 1
                else:
                    self.consecutive_loss_count = 0

                self._check_engine_protection()

                if config.DRY_RUN:
                    pass

            self.logger.info(
                f"자동매도 주문 등록 | symbol={symbol} qty={qty} "
                f"order_id={order.order_id} reason={reason} status={order.status}"
            )

            if order.status == OrderStatus.SUBMITTED:
                self._set_reentry_block(symbol, reason)

            if self.telegram:
                self.telegram.send(
                    f"🔻 자동매도 주문\n"
                    f"종목: {symbol}\n"
                    f"수량: {qty}\n"
                    f"사유: {reason}\n"
                    f"내부주문번호: {order.order_id}\n"
                    f"일일주문: {self.daily_order_count}/{self.max_daily_orders}"
                )

            if order.status == OrderStatus.REJECTED:
                self.sell_in_progress.discard(symbol)

        except Exception as e:
            self.sell_in_progress.discard(symbol)
            self.error_count += 1
            self.logger.exception(f"자동매도 주문 실패 | symbol={symbol} qty={qty} err={e}")
            self._check_engine_protection()

    # -------------------------
    # 오래된 매도 미체결 주문 취소
    # -------------------------
    def _check_stale_sell_order(self, symbol: str):
        try:
            if not config.ENABLE_SELL_CANCEL_TIMEOUT:
                return

            if symbol in self.cancel_in_progress:
                return

            order = self.order_manager.get_open_sell_order_by_symbol(symbol)
            if order is None:
                return

            broker_order_id = None
            for real_id, local_id in self.order_manager.broker_to_local_id.items():
                if local_id == order.order_id:
                    broker_order_id = real_id
                    break

            if not broker_order_id:
                broker_order_id = order.order_id

            order_ts = getattr(order, "ts", None)

            if order_ts is None:
                elapsed = 0.0
            elif isinstance(order_ts, datetime):
                elapsed = time.time() - order_ts.timestamp()
            else:
                elapsed = time.time() - float(order_ts)

            if elapsed < config.SELL_ORDER_TIMEOUT_SEC:
                return

            remain_qty = max(int(order.qty) - int(order.filled_qty), 0)
            if remain_qty <= 0:
                return

            self.cancel_in_progress.add(symbol)

            self.logger.warning(
                f"매도 미체결 타임아웃 | symbol={symbol} local_id={order.order_id} "
                f"broker_id={broker_order_id} elapsed={elapsed:.1f}s remain_qty={remain_qty}"
            )

            ret = self.broker.cancel_order(
                symbol=symbol,
                order_no=broker_order_id,
                qty=remain_qty,
                side=Side.SELL,
            )

            if ret == 0:
                self.last_cancel_request_time[symbol] = time.time()

                order.status = OrderStatus.CANCELED

                try:
                    self.order_manager.orders.pop(order.order_id, None)
                except Exception:
                    pass

                try:
                    remove_keys = []
                    for broker_id, local_id in self.order_manager.broker_to_local_id.items():
                        if local_id == order.order_id:
                            remove_keys.append(broker_id)

                    for broker_id in remove_keys:
                        self.order_manager.broker_to_local_id.pop(broker_id, None)
                except Exception:
                    pass

                self.sell_in_progress.discard(symbol)

                if config.RETRY_SELL_AFTER_CANCEL:
                    self.pending_resell[symbol] = {
                        "qty": remain_qty,
                        "reason": "취소후재매도",
                        "requested_at": time.time(),
                    }

                if self.telegram:
                    self.telegram.send(
                        f"⏳ 매도 미체결 취소 요청\n"
                        f"종목: {symbol}\n"
                        f"내부주문번호: {order.order_id}\n"
                        f"실제주문번호: {broker_order_id}\n"
                        f"잔량: {remain_qty}\n"
                        f"경과: {elapsed:.1f}초"
                    )
            else:
                self.cancel_in_progress.discard(symbol)

        except Exception as e:
            self.cancel_in_progress.discard(symbol)
            self.error_count += 1
            self.logger.exception(f"매도 미체결 취소 검사 실패 | symbol={symbol} err={e}")
            self._check_engine_protection()

    # -------------------------
    # 취소 후 재매도 재시도
    # -------------------------
    def _retry_sell_after_cancel(self, symbol: str):
        try:
            if not config.RETRY_SELL_AFTER_CANCEL:
                return

            pending = self.pending_resell.get(symbol)
            if not pending:
                return

            if symbol in self.sell_in_progress:
                return

            requested_at = float(pending.get("requested_at", 0))
            if time.time() - requested_at < config.RETRY_SELL_DELAY_SEC:
                return

            qty = int(pending.get("qty", 0))
            reason = str(pending.get("reason", "취소후재매도"))

            if qty <= 0:
                self.pending_resell.pop(symbol, None)
                self.cancel_in_progress.discard(symbol)
                return

            pos = self.portfolio.get_position(symbol)
            hold_qty = int(getattr(pos, "qty", 0))
            if hold_qty <= 0:
                self.pending_resell.pop(symbol, None)
                self.cancel_in_progress.discard(symbol)
                return

            sell_qty = min(qty, hold_qty)

            retry_count = self.resell_retry_count.get(symbol, 0)
            if retry_count >= config.RETRY_SELL_MAX_COUNT:
                self.logger.warning(
                    f"재매도 최대 횟수 초과 | symbol={symbol} retry_count={retry_count}"
                )
                self.pending_resell.pop(symbol, None)
                self.cancel_in_progress.discard(symbol)
                self.sell_in_progress.discard(symbol)
                self.abandon_resell_symbols.add(symbol)
                return

            if self.order_manager.exists_open_order(symbol):
                return

            self.sell_in_progress.add(symbol)

            signal = Signal(
                symbol=symbol,
                side=Side.SELL,
                qty=sell_qty,
                price=0,
                order_type=OrderType.MARKET,
                reason=f"{reason}_{retry_count + 1}",
            )

            order = self.broker.place_order(signal)
            self.order_manager.register(order)

            if order.status == OrderStatus.SUBMITTED:
                self.resell_retry_count[symbol] = retry_count + 1
                self.last_order_time[symbol] = time.time()
                self.daily_order_count += 1

                self.logger.warning(
                    f"취소 후 재매도 주문 등록 | symbol={symbol} qty={sell_qty} "
                    f"order_id={order.order_id} retry={self.resell_retry_count[symbol]}"
                )

                self.pending_resell.pop(symbol, None)
                self.cancel_in_progress.discard(symbol)

                if self.telegram:
                    self.telegram.send(
                        f"🔁 취소 후 재매도\n"
                        f"종목: {symbol}\n"
                        f"수량: {sell_qty}\n"
                        f"재시도: {self.resell_retry_count[symbol]}/{config.RETRY_SELL_MAX_COUNT}\n"
                        f"내부주문번호: {order.order_id}"
                    )
            else:
                self.sell_in_progress.discard(symbol)

        except Exception as e:
            self.sell_in_progress.discard(symbol)
            self.error_count += 1
            self.logger.exception(f"취소 후 재매도 실패 | symbol={symbol} err={e}")
            self._check_engine_protection()

    # -------------------------
    # 재진입 제한 설정
    # -------------------------
    def _set_reentry_block(self, symbol: str, reason: str):
        now_ts = time.time()

        if "손절" in reason:
            block_sec = config.REENTRY_BLOCK_SEC_AFTER_STOPLOSS
        else:
            block_sec = config.REENTRY_BLOCK_SEC_AFTER_SELL

        until_ts = now_ts + block_sec
        self.reentry_block_until[symbol] = until_ts
        self.last_exit_reason[symbol] = reason

        self.logger.info(
            f"재진입 제한 설정 | symbol={symbol} reason={reason} "
            f"block_sec={block_sec} until_ts={until_ts}"
        )

    # -------------------------
    # 재진입 가능 여부
    # -------------------------
    def _can_reenter_buy(self, symbol: str):
        until_ts = self.reentry_block_until.get(symbol, 0)
        now_ts = time.time()

        if now_ts < until_ts:
            remain = int(until_ts - now_ts)
            reason = self.last_exit_reason.get(symbol, "최근 청산")
            return False, f"재진입 제한 중({remain}초 남음, 사유={reason})"

        return True, "OK"

    # -------------------------
    # 주문 가능 여부 방어 로직
    # -------------------------
    def can_send_order(self, signal, tick):
        self.reset_daily_counters_if_needed()

        if not self.is_running:
            return False, "엔진 비실행 상태"

        if not self.is_market_open():
            if not config.DRY_RUN:
                return False, "장외 시간"

        if self.daily_order_count >= self.max_daily_orders:
            return False, "일일 최대 주문 횟수 초과"

        if tick.volume < self.min_tick_volume:
            return False, "틱 거래량 기준 미달"

        if self.order_manager.exists_open_order(signal.symbol):
            return False, "미체결/진행중 주문 존재"

        now_ts = time.time()
        last_ts = self.last_order_time.get(signal.symbol, 0.0)
        if now_ts - last_ts < self.order_cooldown_sec:
            return False, f"주문 쿨타임 {self.order_cooldown_sec}초 이내"

        if signal.side.value == "BUY":
            ok_reenter, reason_reenter = self._can_reenter_buy(signal.symbol)
            if not ok_reenter:
                return False, reason_reenter

        pos = self.portfolio.get_position(signal.symbol)
        if signal.side.value == "BUY":
            if pos.qty >= self.max_symbol_position:
                return False, "종목당 최대 보유 제한"

        ok, reason = self.risk_manager.can_trade(signal, self.portfolio)
        if not ok:
            return False, reason

        return True, "OK"

    # -------------------------
    # 틱 처리
    # -------------------------
    def on_tick(self, tick: TickData):
        self.logger.info(
            f"[CHECK] {tick.symbol} "
            f"price={tick.price} vol={tick.volume} "
            f"chg={getattr(tick, 'price_change_pct', 0.0)} "
            f"strength={getattr(tick, 'trade_strength', 0.0)} "
            f"vr={getattr(tick, 'volume_ratio', 0.0)} "
            f"news={getattr(tick, 'news_score', 0.0)} "
            f"theme={getattr(tick, 'theme_score', 0.0)} "
            f"leader={getattr(tick, 'leader_score', 0.0)}"
        )

        if not self.is_running:
            return

        signal = self.strategy.generate_signal(tick, self.portfolio)
        if signal is None:
            return

        entry_score = self._extract_score_from_reason(getattr(signal, "reason", ""))

        self.logger.info(
            f"[SIGNAL] {signal.symbol} side={signal.side} qty={signal.qty} "
            f"score={entry_score} reason={signal.reason}"
        )

        ok, reason = self.can_send_order(signal, tick)
        if not ok:
            self.logger.info(
                f"[{signal.symbol}] 주문 차단 | {reason} | "
                f"score={entry_score} chg={getattr(tick, 'price_change_pct', 0.0)} "
                f"strength={getattr(tick, 'trade_strength', 0.0)} "
                f"vr={getattr(tick, 'volume_ratio', 0.0)}"
            )
            return

        try:
            self.logger.info(
                f"[ORDER_READY] {signal.symbol} side={signal.side} qty={signal.qty} "
                f"score={entry_score} reason={signal.reason}"
            )

            order = self.broker.place_order(signal)
            self.order_manager.register(order)

            if order.status == OrderStatus.SUBMITTED:
                self.last_order_time[signal.symbol] = time.time()
                self.daily_order_count += 1

                if signal.side.value == "BUY" and hasattr(self.strategy, "mark_entry"):
                    self.strategy.mark_entry(signal.symbol, tick.ts)

            if config.DRY_RUN:
                if signal.side.value == "BUY":
                    class StubFill:
                        pass

                    fill = StubFill()
                    fill.order_id = order.order_id
                    fill.symbol = order.symbol
                    fill.side = order.side
                    fill.fill_qty = order.qty
                    fill.fill_price = tick.price
                    fill.unfilled_qty = 0

                    self.on_fill(fill)

            self.logger.info(
                f"주문 등록 | id={order.order_id} symbol={order.symbol} "
                f"side={order.side} qty={order.qty} count={self.daily_order_count}/{self.max_daily_orders} "
                f"score={entry_score}"
            )

            if self.telegram:
                self.telegram.send(
                    f"📈 주문 발생\n"
                    f"종목: {order.symbol}\n"
                    f"방향: {order.side}\n"
                    f"수량: {order.qty}\n"
                    f"상태: {order.status}\n"
                    f"점수: {entry_score}\n"
                    f"사유: {signal.reason}\n"
                    f"일일주문: {self.daily_order_count}/{self.max_daily_orders}"
                )

            if order.status == OrderStatus.REJECTED:
                self.logger.warning(f"주문 거부 | {order.symbol}")
                if self.telegram:
                    self.telegram.send(
                        f"❌ 주문 거부\n"
                        f"종목: {order.symbol}\n"
                        f"방향: {order.side}\n"
                        f"수량: {order.qty}\n"
                        f"점수: {entry_score}\n"
                        f"사유: {signal.reason}"
                    )

        except Exception as e:
            self.error_count += 1
            self.logger.exception(f"주문 처리 실패 | {e}")
            self._check_engine_protection()
            if self.telegram:
                self.telegram.send(f"🚨 주문 처리 실패\n{tick.symbol}\n{e}")

    # -------------------------
    # 체결 반영
    # -------------------------
    def on_fill(self, fill):
        try:
            local_order_id = self.order_manager.bind_broker_order_id(
                symbol=fill.symbol,
                broker_order_id=fill.order_id
            )
            resolved_order_id = local_order_id or self.order_manager.resolve_order_id(fill.order_id)

            self.portfolio.update_fill(fill)

            order = self.order_manager.apply_fill(
                order_id=resolved_order_id,
                fill_qty=fill.fill_qty,
                fill_price=fill.fill_price,
                unfilled_qty=getattr(fill, "unfilled_qty", None)
            )

            if order is None:
                self.logger.warning(
                    f"체결은 들어왔지만 주문 매핑 실패 | broker_id={fill.order_id} "
                    f"symbol={fill.symbol} qty={fill.fill_qty} price={fill.fill_price}"
                )
            else:
                self.logger.info(
                    f"체결 반영 | broker_id={fill.order_id} local_id={resolved_order_id} "
                    f"symbol={fill.symbol} side={fill.side} "
                    f"fill_qty={fill.fill_qty} fill_price={fill.fill_price} "
                    f"cum_filled={order.filled_qty}/{order.qty} status={order.status}"
                )

            self.logger.info(
                f"잔고 상태 | cash={self.portfolio.cash:.0f} realized_pnl={self.portfolio.realized_pnl:.0f}"
            )

            if self.telegram:
                status_text = order.status if order else "UNKNOWN"
                cum_text = f"{order.filled_qty}/{order.qty}" if order else f"{fill.fill_qty}/?"
                self.telegram.send(
                    f"✅ 체결\n"
                    f"종목: {fill.symbol}\n"
                    f"방향: {fill.side}\n"
                    f"주문번호(실제): {fill.order_id}\n"
                    f"주문번호(내부): {resolved_order_id}\n"
                    f"이번체결: {fill.fill_qty}\n"
                    f"체결가: {fill.fill_price}\n"
                    f"누적체결: {cum_text}\n"
                    f"상태: {status_text}"
                )

            try:
                if getattr(fill.side, "name", "") == "SELL":
                    self.sell_in_progress.discard(fill.symbol)
                    self.logger.info(
                        f"매도 체결 완료 | symbol={fill.symbol} "
                        f"reentry_reason={self.last_exit_reason.get(fill.symbol, '')}"
                    )
            except Exception:
                pass

            try:
                pos = self.portfolio.get_position(fill.symbol)
                if int(getattr(pos, "qty", 0)) == 0:
                    self.partial_exit_done.discard(fill.symbol)
                    self.breakeven_active.discard(fill.symbol)
                    self.trailing_high_price.pop(fill.symbol, None)
                    self.logger.info(f"청산 상태 초기화 | symbol={fill.symbol}")
            except Exception:
                pass

            try:
                pos = self.portfolio.get_position(fill.symbol)
                if int(getattr(pos, "qty", 0)) == 0:
                    self.pending_resell.pop(fill.symbol, None)
                    self.resell_retry_count.pop(fill.symbol, None)
                    self.last_cancel_request_time.pop(fill.symbol, None)
                    self.abandon_resell_symbols.discard(fill.symbol)
            except Exception:
                pass

            try:
                self.cancel_in_progress.discard(fill.symbol)
            except Exception:
                pass

        except Exception as e:
            self.error_count += 1
            self.logger.exception(f"체결 반영 실패 | {e}")
            self._check_engine_protection()
            if self.telegram:
                self.telegram.send(f"🚨 체결 반영 실패\n{fill.symbol}\n{e}")

    # -------------------------
    # 엔진 보호모드 체크
    # -------------------------
    def _check_engine_protection(self):
        try:
            if self.consecutive_loss_count >= config.MAX_CONSECUTIVE_LOSS:
                self._trigger_protection(f"연속 손절 {self.consecutive_loss_count}회")

            if self.portfolio.realized_pnl <= config.MAX_DAILY_LOSS:
                self._trigger_protection(f"일일 손실 초과 {self.portfolio.realized_pnl}")

            if self.error_count >= config.MAX_ERROR_COUNT:
                self._trigger_protection(f"오류 누적 {self.error_count}회")

        except Exception as e:
            self.logger.exception(f"보호모드 체크 실패 | {e}")

    def _trigger_protection(self, reason: str):
        if self.engine_protected:
            return

        self.engine_protected = True

        self.logger.error(f"🚨 엔진 보호모드 발동 | reason={reason}")

        if self.telegram:
            self.telegram.send(
                f"🚨 자동매매 중지\n"
                f"사유: {reason}\n"
                f"PnL: {self.portfolio.realized_pnl:.0f}"
            )

        self.stop()

    # -------------------------
    # 초기 포지션 동기화
    # -------------------------
    def sync_portfolio(self):
        try:
            balance = self.broker.get_balance()

            self.logger.info("초기 잔고 동기화 시작")

            for symbol, data in balance.items():
                qty = int(data["qty"])
                avg_price = float(data["avg_price"])

                if qty <= 0:
                    continue

                self.portfolio.positions[symbol].qty = qty
                self.portfolio.positions[symbol].avg_price = avg_price

                self.logger.info(
                    f"보유 종목 | symbol={symbol} qty={qty} avg_price={avg_price}"
                )

            self.logger.info("초기 잔고 동기화 완료")

        except Exception as e:
            self.logger.exception(f"포트폴리오 동기화 실패 | {e}")

    def health_check(self):
        try:
            total_qty = sum(p.qty for p in self.portfolio.positions.values())

            self.logger.info(f"헬스체크 | 총 보유수량={total_qty}")

            if total_qty > 50:
                self.logger.warning("보유 수량 과다 - 확인 필요")

        except Exception as e:
            self.logger.exception(f"헬스체크 실패 | {e}")

    # -------------------------
    # 서버 메시지
    # -------------------------
    def on_broker_msg(self, text: str):
        self.logger.info(text)

        cancel_keywords = ["취소", "정정", "거부", "실패", "오류"]
        if any(k in text for k in cancel_keywords):
            try:
                for symbol in list(self.cancel_in_progress):
                    self.cancel_in_progress.discard(symbol)
            except Exception:
                pass

        error_keywords = ["실패", "오류", "거부", "에러", "제한"]
        if self.telegram and any(k in text for k in error_keywords):
            self.telegram.send(f"⚠️ 서버 메시지\n{text}")